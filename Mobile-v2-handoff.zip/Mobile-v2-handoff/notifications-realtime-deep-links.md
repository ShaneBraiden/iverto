# Notifications, Realtime, and Deep Links

This document defines the lifecycle, security invariants, and integration contracts for push notifications, foreground realtime events, and background deep links across mobile clients.

## Core Lifecycle Invariants

- Register one push device per authenticated session/device; unregister on logout and accept server invalidation of stale provider tokens.
- Background push contains only event type, opaque resource ID, and allowlisted `iverto://` URI. Fetch protected detail after foreground authentication.
- Foreground realtime authenticates with the in-memory access token, accepts only server-derived rooms, reconnects after refresh, and revalidates authorization revision.
- A notification-resource event invalidates inbox and unread count. Resource events invalidate list, detail, summary, and dashboard keys only when their nested resource version is newer.
- A branding-resource event invalidates effective branding; refetch `GET /me/branding` before applying it, and keep launch/resume fetch as authoritative.
- Never put a bearer/refresh token, OTP, invitation, signed URL, person name, phone, email, reason, document, or biometric value in push data or a deep link.

---

## 1. Push Device Registration & Lifecycle

Mobile clients register their device tokens via session-bound endpoints:

- **Endpoint**: `POST /hostel/v2/me/push-devices`
- **Payload (`PushDeviceRegistration`)**:
  - `installationId`: Stable client-side UUID per app installation.
  - `platform`: `'ios' | 'android'`.
  - `token`: APNs device token or FCM registration token.
  - `appVersion`: Client semantic version (e.g. `'2.4.0'`).
  - `locale`: Client BCP-47 language tag (e.g. `'en-IN'`).
- **Response (`PushDeviceView`)**:
  - Device identifier, installation identifier, active status, version, and last seen timestamp.
  - **Write-Only Tokens**: Provider push tokens are write-only. They are never returned in read views or query responses.
- **Unregistration**:
  - On explicit logout or account switch, clients call `DELETE /hostel/v2/me/push-devices/{deviceId}`.
  - When push providers report expired or invalid tokens, the backend marks devices inactive and evicts stale device records.

---

## 2. Background Push Notifications

Background push payloads must remain minimal and privacy-preserving:

```json
{
  "type": "permission.updated",
  "resourceId": "perm-01912f7a-8b1c-7000-8000-000000000001",
  "deepLink": "iverto://permissions/perm-01912f7a-8b1c-7000-8000-000000000001"
}
```

- **Zero-Trust Payloads**: Background notifications must NEVER include:
  - Access/refresh tokens, session cookies, or OTP codes.
  - Invitation codes, password reset links, or signed storage URLs.
  - Personally identifiable information (PII): student names, guardian contact details, phone numbers, email addresses.
  - Sensitive operational details: leave reasons, medical documents, parent notes, or biometric data.
- **Client Execution**: Tapping a notification opens the deep link inside the app. The client verifies local session authentication before fetching domain data from authenticated API endpoints.

---

## 3. Foreground Realtime Connection & Rooms

Foreground realtime streams deliver event metadata to active sessions:

- **Transport**: WebSocket / SSE with TLS.
- **Authentication**: Authenticates using the short-lived in-memory access token passed during handshake.
- **Server-Derived Rooms**: The server joins connections only to rooms derived from the authenticated principal's active tenant and role assignments (e.g., `tenant:{tenantId}:user:{userId}`, `tenant:{tenantId}:role:{role}`). Clients cannot subscribe to arbitrary rooms or topics.
- **Reconnection & Token Refresh**:
  - Upon token expiration or connection disruption, the client refreshes its token via the `RefreshMutex`.
  - The realtime client reconnects with the fresh access token and verifies whether `authorizationRevision` has changed.
  - If `authorizationRevision` differs from cached queries, the client invalidates all tenant-scoped queries immediately.

---

## 4. Safe Cache Invalidation (React Query)

Realtime events use a locked nested envelope:

```typescript
export interface RealtimeEvent {
  readonly type: string;
  readonly version: 1;
  readonly resource: {
    readonly type: string;
    readonly id: string;
    readonly version: string;
  };
  readonly summary: Readonly<Record<string, string | number | boolean | null>>;
  readonly occurredAt: string;
}
```

- **Query Invalidation Only**: Realtime events MUST NOT perform client-side optimistic domain mutations. They map to cache invalidation tuples via `invalidationForEvent(event)`:
  - `['Permission', event.resource.id]` invalidates specific permission detail and associated lists.
  - `['Notification', event.resource.id]` invalidates notification inbox pages and unread badge count queries.
  - `['Branding', event.resource.id]` invalidates the `GET /me/branding` query key.
- **Monotonic Version Ordering**: Resource updates only trigger query refetches when the event's `resource.version` is strictly newer than the cached item's version, preventing stale out-of-order events from overwriting fresh data.

---

## 5. Strict Deep Link Allowlist

Deep links are validated against an immutable allowlist using `parseDeepLink`:

| Deep Link Pattern | Target Destination | Screen / Context |
|---|---|---|
| `iverto://permissions/{id}` | `{ screen: 'permission', id }` | Permission detail modal or screen |
| `iverto://notifications` | `{ screen: 'notifications' }` | Notifications inbox |
| `iverto://profile-requests` | `{ screen: 'profile-requests' }` | Student profile change requests |

### Security Rejection Rules
- Any URL with protocol other than `iverto:` (e.g. `http:`, `https:`, `javascript:`, `file:`) returns `null`.
- Empty resource IDs (e.g. `iverto://permissions/`) return `null`.
- Undeclared hostnames or routes (e.g. `iverto://malicious/path`, `iverto://auth/token`) return `null`.
- On receiving a rejected or malformed deep link, the application discards the link and routes the user safely to the authenticated root dashboard.
