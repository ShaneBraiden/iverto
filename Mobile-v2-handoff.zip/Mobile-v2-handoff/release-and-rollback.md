# Mobile Release, Versioning, and Rollback Runbook

This runbook defines the operational procedures, distribution channels, monitoring thresholds, rollback protocols, and sign-off authorities for deploying and maintaining the Iverto Hostel V2 mobile application across Apple App Store and Google Play Store.

---

## 1. Release Channels & Progression

Every mobile application release must progress sequentially through four controlled distribution channels:

```
[ Internal Channel ] ──> [ Staging Channel ] ──> [ Phased Production ] ──> [ Mandatory Update ]
```

| Channel | Target Audience | Distribution Mechanism | Purpose & Verification Gate |
|---|---|---|---|
| **1. Internal** | Core engineering and QA teams | Expo Internal Distribution / TestFlight Internal | Feature branch testing, local mock verification, regression checks. |
| **2. Staging** | External QA, tenant pilot testers, accessibility auditors | TestFlight Public Beta / Google Play Internal Testing | End-to-end testing against staging backend, contract conformance, zero-leak audits. |
| **3. Phased Production** | General tenant users (students, guardians, staff) | App Store Phased Release / Google Play Staged Rollout | Gradual rollout (1% -> 5% -> 20% -> 50% -> 100%) monitoring telemetry thresholds. |
| **4. Mandatory Update** | All active mobile clients | In-app block via `/app-config` `minimum app version` | Hard gate blocking deprecated or insecure builds from accessing the API. |

---

## 2. Release Prerequisites & Contract Pinning

Before promoting any release candidate to Phased Production:
1. **External App Commit Tracking**: The exact Git commit hash of the external mobile application (`external app commit`), along with the native binary build numbers (iOS CFBundleVersion, Android versionCode), must be documented and tagged in version control.
2. **Contract Hash Verification**: The release build must be compiled and tested against the canonical bundle hash (`contract hash`) recorded in `contracts/openapi/hostel-v2.bundle.sha256`.
3. **Signed Acceptance Manifest**: The external mobile team must submit a signed acceptance manifest confirming that all role flows, deep links, uploads, and accessibility standards have passed verification.
4. **Strict Invariant: Server V1 Retention**: Legacy server v1 endpoints must remain active and unmodified throughout the release. Under no circumstance may server v1 code be deleted or deprecated before signed external acceptance is certified.
5. **Strict Invariant: Minimum Version Gating**: The backend `minimum app version` must NEVER be elevated prior to signed external acceptance and completion of full phased rollout.

---

## 3. Telemetry Anomaly Triggers and Halt Thresholds

During phased rollout, automated monitoring watches for anomalies. If any of the following metric thresholds are breached within a 60-minute window, the rollout must be halted immediately:

| Metric Category | Rollback Trigger Threshold | Verification Method |
|---|---|---|
| **Crash Rate** | > 0.10% of active sessions (or 5x baseline) | Crashlytics / Sentry crash-free session rate |
| **Auth / Refresh Failure** | > 0.50% of token refresh attempts failing with 4xx/5xx | Auth gateway metrics & token rotation counters |
| **Server Error Rate (5xx)** | > 1.00% of all mobile API calls | Ingress API gateway HTTP status logs |
| **Push Notification Delivery** | > 2.00% delivery or payload parsing errors | APNs / FCM error reporting & receipt telemetry |
| **Deep Link Routing Failure** | > 1.00% fallback unhandled route dispatches | Route dispatch breadcrumbs & analytics |
| **Upload Failure Rate** | > 1.00% failed presigned S3/MinIO transfers | Storage scanner logs & client upload telemetry |

---

## 4. Rollback Procedures

### 4.1 Rollback Before Minimum App Version Enforcement
When an issue is detected while the previous build is still supported (i.e. `minimum app version` has not been raised):
1. **Halt Rollout**:
   - iOS: In App Store Connect, select *Pause Phased Release*.
   - Android: In Google Play Console, select *Halt rollout* on the production release track.
2. **Revert Active Build**:
   - Re-release or increase the rollout percentage of the previously stable production build.
3. **Incident Declaration**:
   - Open a severity incident, document the failing `external app commit`, and preserve client telemetry logs for triage.

### 4.2 Rollback After Minimum App Version Enforcement
If a critical defect is identified after the minimum version has already been increased:
1. **Emergency Evaluation**:
   - Assess whether the defect poses security or data integrity risks that outweigh blocking users.
2. **Coordinated App-Config Downgrade**:
   - If the previous app build is safe and compatible with the current backend contract, platform operators can execute a signed configuration change to lower the `minimum app version` in `/app-config`.
   - Restore access for the previous version while halting rollout of the defective build.
3. **Expedited Hotfix Release**:
   - If the previous build is incompatible, an expedited emergency hotfix must be built, tagged against the current `contract hash`, verified via smoke tests, and submitted to Apple and Google under expedited review procedures.

---

## 5. Named Sign-Off Authorities

No release candidate may be promoted to production without recorded sign-off from each of the following named roles:

1. **Mobile Engineering Lead**: Validates code quality, dependency security, bundle hash adherence, and native performance.
2. **Backend / Platform Lead**: Validates server capacity, database query compatibility, and ingress gateway routing.
3. **Security & Compliance Lead**: Validates zero-secret storage, token rotation, TLS configuration, and telemetry redaction.
4. **Accessibility Lead**: Validates WCAG 2.1 AA checklist compliance, screen reader navigation, and touch target sizing.
5. **Release Manager**: Coordinates phased release schedules, store submissions, and rollback readiness.
6. **Tenant Product Owner**: Validates tenant branding, role workflows, and end-user acceptance.
