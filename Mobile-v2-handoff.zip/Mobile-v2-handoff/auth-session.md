# Mobile Authentication And Session Sequence

1. Resolve public branding and status with `GET /tenant-discovery/{code}`; do not expose whether a person exists.
2. Activate a bound invitation with `POST /auth/invitations/{token}/activate` when the launch link contains an invitation token.
3. Authenticate with `POST /auth/password/login`, or request and verify OTP with `POST /auth/otp/request` and `POST /auth/otp/verify`.
4. Complete `POST /auth/mfa/challenge` and `POST /auth/mfa/verify` whenever the server requires enrollment or step-up.
5. Keep the access token in memory. Store only the rotating refresh token under `iverto.hostel.v2.refresh-token` through Expo SecureStore.
6. Call `GET /auth/session`; route from its server-resolved role and authority, never from the login picker or JWT metadata.
7. On one eligible 401, pause concurrent requests, call `POST /auth/refresh` once, atomically replace the SecureStore refresh token, and replay each request once.
8. A refresh replay, revoked session, disabled principal, tenant suspension, stale authorization revision, or second 401 clears memory and SecureStore and routes to tenant-code entry.
9. Password recovery uses request and completion endpoints. Authenticated password change rotates the session.
10. Tenant switch uses `POST /auth/tenant-switch`, replaces both tokens, clears tenant query caches, closes realtime, then reconnects under the returned tenant.
11. Logout calls `POST /auth/logout`, unregisters the push device when possible, and clears local tokens even when the network call fails.
12. Offline reads may use previously rendered non-sensitive data only until access expiry. No mutation is queued across expiry.
