# Environment, TLS, and Network Security Runbook

This runbook specifies transport layer security (TLS), certificate validation, network timeout boundaries, and platform security configurations required for the Iverto Hostel V2 mobile application.

---

## 1. Transport Layer Security (TLS) Standards

All communication between the mobile client and Hostel V2 services must strictly use secure cryptographic protocols.

1. **Protocol Versions**:
   - TLS 1.3 is the required default protocol.
   - TLS 1.2 is permitted as the minimum fallback for legacy device compatibility.
   - SSL v3, TLS 1.0, and TLS 1.1 are explicitly disabled on all edge gateways and ingress controllers.

2. **Cipher Suites**:
   - Only modern forward-secrecy cipher suites are supported:
     - `TLS_AES_256_GCM_SHA384`
     - `TLS_CHACHA20_POLY1305_SHA256`
     - `TLS_AES_128_GCM_SHA256`
     - `ECDHE-ECDSA-AES256-GCM-SHA384`
     - `ECDHE-RSA-AES256-GCM-SHA384`

3. **Certificate Validation**:
   - Standard X.509 certificate path validation is mandatory against trusted platform root certificate stores.
   - Wildcard certificates are limited to single-level domain names (e.g., `*.hostel.iverto.io`).
   - Self-signed certificates are rejected by production and staging builds under all circumstances.

---

## 2. Certificate Pinning Guidelines

To defend against active machine-in-the-middle (MITM) attacks and compromised public Certificate Authorities (CAs):

1. **Public Key Pinning (SPKI)**:
   - Certificate pinning targets the SHA-256 hash of the Subject Public Key Information (SPKI) rather than the entire X.509 leaf certificate. This allows CA re-issuance without rotating the key pair.
2. **Backup Pins**:
   - Every pinning configuration must declare at least one primary pin and one cold backup pin from an independent intermediate or root authority.
   - Never deploy a single pin configuration; failure to rotate keys before certificate expiration can permanently brick mobile connectivity.
3. **Pin Lifetime & Rotation Strategy**:
   - Mobile pins are rotated on a 90-day cycle with a minimum 60-day overlap between outgoing and incoming pins.
   - Emergency pin updates are delivered via expedited store releases; dynamic pinning updates over cleartext or unauthenticated channels are prohibited.

---

## 3. Environment Endpoints

The mobile client targets three distinct operating environments:

| Environment | Purpose | REST Base URL | Realtime (WebSocket) URL |
|---|---|---|---|
| **Local Mock** | Local offline development and contract testing | `http://127.0.0.1:4010/hostel/v2` | N/A (Mocked in memory) |
| **Staging** | External app integration, QA, and acceptance gates | `https://staging-api.hostel.iverto.io/hostel/v2` | `wss://staging-api.hostel.iverto.io` |
| **Production** | Live tenant operations | `https://api.hostel.iverto.io/hostel/v2` | `wss://api.hostel.iverto.io` |

*Note: The local mock server binds exclusively to `127.0.0.1` loopback and does not accept remote network traffic.*

---

## 4. Network Timeout Boundaries

Network operations must implement deterministic timeout thresholds to prevent UI hangs and connection pool exhaustion:

| Operation Type | Timeout | Behavior on Expiry |
|---|---|---|
| **TCP Connection** | 10,000 ms (10s) | Terminate connection attempt, display offline or connectivity warning banner. |
| **Read Queries (GET)** | 15,000 ms (15s) | Abort request, fall back to cached projection if available, surface stale indicator. |
| **State Mutations (POST/PUT/PATCH/DELETE)** | 20,000 ms (20s) | Abort request, surface explicit retry action. Do NOT automatically replay un-idempotent operations. |
| **Document / Photo Uploads** | 60,000 ms (60s) | Abort multipart upload, prompt user to resume or reselect file. |
| **Realtime Ping-Pong** | Ping: 25,000 ms, Timeout: 20,000 ms | Disconnect socket, execute exponential backoff reconnection. |

---

## 5. Platform Network Security Configurations

Cleartext HTTP traffic (`http://`) is completely prohibited on staging and production mobile builds.

### Android: `res/xml/network_security_config.xml`
```xml
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="false">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
    <domain-config>
        <domain includeSubdomains="true">hostel.iverto.io</domain>
        <pin-set expiration="2027-01-01">
            <pin digest="SHA-256">47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=</pin>
            <pin digest="SHA-256">k2ErWTvE4nvR9+Wqcy4IxVWZJaRIOzcZo/2Vps5cUMo=</pin>
        </pin-set>
    </domain-config>
</network-security-config>
```
*In AndroidManifest.xml: `android:networkSecurityConfig="@xml/network_security_config"`.*

### iOS: `Info.plist` App Transport Security (ATS)
```xml
<key>NSAppTransportSecurity</key>
<dict>
    <key>NSAllowsArbitraryLoads</key>
    <false/>
    <key>NSExceptionDomains</key>
    <dict>
        <key>hostel.iverto.io</key>
        <dict>
            <key>NSIncludesSubdomains</key>
            <true/>
            <key>NSExceptionRequiresForwardSecrecy</key>
            <true/>
            <key>NSExceptionMinimumTLSVersion</key>
            <string>TLSv1.2</string>
        </dict>
    </dict>
</dict>
```
