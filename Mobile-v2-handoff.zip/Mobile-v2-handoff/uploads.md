# Mobile Uploads, Signed Downloads, Validation, and Quarantine Runbook

This document defines the 9-phase upload lifecycle, pre-upload validation policies, quarantine scanning barriers, short-lived download URLs, and cleanup workflows for the mobile client.

---

## 9-Phase Upload Lifecycle Runbook

1. Pick a client-native document or image and reject empty, disallowed, or over-5-MiB input locally.
2. Downscale branding to at most 512 px on its longest edge and prefer WebP when the platform encoder supports it.
3. `POST /tenants/{tenantId}/uploads` as multipart with purpose; keep upload progress in memory.
4. Store only returned `fileId`, status, metadata, and checksum in form state. Never parse an object key.
5. If `scanState` is `pending`, the object remains quarantined; poll bounded metadata or consume invalidation, and keep attachment submission disabled.
6. Attach only `clean` or `not-required` file IDs. Show infected/failed reason code without provider or scanner details.
7. Request `POST /uploads/{fileId}/download-url` immediately before viewing a private object; its lifetime is at most 300 seconds, and the app does not persist or log the URL or its query.
8. Branding URLs are immutable render URLs when public; private deployment URLs are refreshed from branding metadata on launch.
9. Delete abandoned uploads through the authorized delete workflow. Do not issue direct Storage calls.

---

## Pre-Upload Policy

- **Maximum File Size**: 5 MiB (`5 * 1024 * 1024` bytes). Files with size < 1 byte fail with `FILE_EMPTY`. Files exceeding 5 MiB fail with `FILE_TOO_LARGE`.
- **Purpose-Specific MIME Types**:
  - `permission`: `application/pdf`, `image/jpeg`, `image/png`, `image/heic`, `image/webp`.
  - `profile-request`: `application/pdf`, `image/jpeg`, `image/png`, `image/heic`, `image/webp`.
  - `branding`: `image/jpeg`, `image/png`, `image/heic`, `image/webp` (PDF is strictly rejected).
- **Unsupported MIME Types**: Reject with `MIME_NOT_ALLOWED`.

---

## Quarantine and Scan States

Uploads are tracked across the following scan states:
- `not-required`: Scan is not required (e.g. system generated or exempt assets). Safe to attach.
- `pending`: Under quarantine scan (ClamAV / security scanner). Gated; client must disable attachment submission.
- `clean`: Scan succeeded with no findings. Safe to attach.
- `infected`: Malicious payload detected. Attachment blocked permanently; client shows generic reason code without exposing scanner internals.
- `failed`: Scanner or processing failure. Attachment blocked.

Attachment eligibility is gated by:
```typescript
canAttachUpload(upload: { scanState: UploadScanState }): boolean
```
Which returns `true` only for `clean` and `not-required`.

---

## Expiring Signed URLs Freshness

Signed URLs for private file viewing:
- Maximum lifetime of 300 seconds.
- Checked using `isSignedUrlFresh(expiresAt, now)`: requires strictly more than 30 seconds of remaining validity (`Date.parse(expiresAt) - now.getTime() > 30_000`). If `<= 30s` remain or the URL has expired, a new download URL must be requested.
- Client must never log or persist signed download URLs or their query parameters.
