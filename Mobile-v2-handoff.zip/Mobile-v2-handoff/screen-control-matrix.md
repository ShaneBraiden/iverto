# Mobile Screen Control Classification Matrix

## 1. Overview & Architectural Invariant

This document defines the complete classification and mapping of every documented mobile UI control and legacy/edge operation for the Iverto Hostel mobile client. It serves as the authoritative specification for frontend screen behavior and backend integration in Hostel v2.

### Classification Taxonomy

Every control is mapped into exactly one of five mutually exclusive classifications:
1. **`v2`**: Supported through authoritative backend Hostel v2 OpenAPI operations. Client requests must use generated client facades, enforce transport security, and submit mandatory headers (`Idempotency-Key`, `If-Match` where required).
2. **`client-native`**: Handled entirely on-device by operating system primitives or client libraries (e.g., native keypad, date-time pickers, tel/SMS system intents, system share sheet, Expo dynamic app icon setter) with zero backend dependency.
3. **`decorative`**: Pure visual presentation element without backend verification or authoritative state (e.g., decorative QR glyph on the outpass screen).
4. **`obsolete`**: Legacy v1 or hardware-coupling features permanently removed from the mobile architecture and backend.
5. **`prohibited`**: Operations strictly forbidden on mobile devices due to security, auditability, and physical integrity guarantees (e.g., direct M50 door unlock, remote wipe, log deletion).

---

## 2. Classification Summary

| Classification | Total Controls | Description |
| :--- | :--- | :--- |
| **`v2`** | 58 | Authoritative backend endpoints backed by v2 OpenAPI operations |
| **`client-native`** | 8 | Native on-device OS capabilities (dialer, SMS, dynamic launcher icon, date pickers) |
| **`decorative`** | 1 | Non-authoritative visual glyph (`permission.decorative-qr`) |
| **`obsolete`** | 5 | Retired legacy patterns (`admin.scan-pass`, `python-edge`, `camera-webrtc`, `custom-gallery-vector`, `edge-ota`) |
| **`prohibited`** | 6 | Forbidden hardware control operations (`prohibited.m50-*`) |
| **Total** | **78** | **Exhaustively accounted controls** |

---

## 3. Comprehensive Screen Control Matrix

| Control ID | Documented Screen / Location | Role | Classification | v2 Operation IDs | Description & Verification |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `auth.role-picker-login` | `app/index.tsx:36-154` | `common` | `v2` | `resolveTenantDiscovery`, `loginWithPassword`, `getCurrentSession` | Role picker configures login keyboard; server discovers tenant and issues authenticated session. |
| `auth.forgot-password` | `app/index.tsx:146` | `common` | `v2` | `requestPasswordRecovery`, `completePasswordRecovery` | Two-step password recovery via recovery email/SMS token. |
| `auth.otp` | `app/index.tsx:162`, `app/otp.tsx` | `common` | `v2` | `requestOtp`, `verifyOtp` | OTP challenge dispatch and verification returning session credentials. |
| `auth.otp-keypad` | `app/otp.tsx:38-62` | `common` | `client-native` | *None* | Custom 6-digit numeric keypad with haptic feedback. |
| `auth.otp-resend` | `app/otp.tsx:66` | `common` | `v2` | `requestOtp` | Resend OTP code after countdown expiration. |
| `auth.change-password` | `components/ProfileBody.tsx:125` | `common` | `v2` | `changePassword` | Authenticated credential rotation requiring current password verification. |
| `auth.logout` | `components/ProfileBody.tsx:136` | `common` | `v2` | `logoutSession`, `revokeSelfPushDevice` | Invalidate current session and unregister push notification token. |
| `student.home-summary` | `app/student/index.tsx:24-38` | `student` | `v2` | `getSelfPermissionSummary` | Server-aggregated summary cards: active pass, approved, pending, and rejected counters. |
| `student.new-request` | `app/student/request.tsx` | `student` | `v2` | `listPermissionCategories`, `submitSelfPermission` | Permission category lookup and idempotent request submission with destination and contact. |
| `student.date-time-picker` | `app/student/request.tsx:56-63` | `student` | `client-native` | *None* | On-device native date and time picker modals. |
| `student.attachment` | `app/student/request.tsx:94-102` | `student` | `v2` | `createUpload`, `getUpload` | Upload supporting PDF or image document (max 5 MB) via presigned object storage flow. |
| `student.history` | `app/student/history.tsx` | `student` | `v2` | `listSelfPermissions` | Paginated outpass history with status filtering (Pending, Approved, Rejected, Expired). |
| `student.history-search` | `app/student/history.tsx:19` | `student` | `v2` | `listSelfPermissions` | Search query param (`q`) filtered server-side across permission history. |
| `student.cancel` | `app/outpass/[id].tsx:147` | `student` | `v2` | `cancelSelfPermission` | Student self-cancellation for draft or pending permission before warden action. |
| `permission.status` | `app/outpass/[id].tsx` | `common` | `v2` | `getSelfPermission`, `getGuardianPermission`, `getPermission` | Current lifecycle state banner, decision maker, and resource version. |
| `permission.decorative-qr` | `app/outpass/[id].tsx` | `common` | `decorative` | *None* | Purely decorative QR glyph; gate verification is exclusively handled by terminal edge sensors. |
| `permission.requester` | `app/outpass/[id].tsx` | `staff` | `v2` | `getPermission` | Requester metadata block (student room, contact, photo, emergency contacts). |
| `permission.timeline` | `app/outpass/[id].tsx` | `common` | `v2` | `getSelfPermission`, `getGuardianPermission`, `getPermission` | Server-ordered timeline events: submission, guardian approval, warden clearance, gate transitions. |
| `permission.share` | `app/outpass/[id].tsx` | `common` | `client-native` | *None* | Native OS share sheet invocation to export or share pass details. |
| `permission.guardian-approve` | `app/outpass/[id].tsx:150` | `guardian` | `v2` | `decidePermissionAsGuardian` | Guardian approval sending `If-Match` version header and idempotency key. |
| `permission.guardian-reject` | `app/outpass/[id].tsx:151` | `guardian` | `v2` | `decidePermissionAsGuardian` | Guardian rejection with mandatory reason note, version precondition, and idempotency. |
| `permission.student-cancel` | `app/outpass/[id].tsx:147` | `student` | `v2` | `cancelSelfPermission` | Student outpass cancellation with concurrency control. |
| `permission.admin-activate` | `app/outpass/[id].tsx` | `admin` | `v2` | `activatePermission` | Admin/warden direct manual activation with site scope and version check. |
| `permission.admin-override` | `app/outpass/[id].tsx` | `admin` | `v2` | `overridePermission` | Administrative manual override with reason, step-up MFA verification, and audit logging. |
| `guardian.queue` | `app/parent/index.tsx:38, 132-149` | `guardian` | `v2` | `listGuardianPermissions` | Real-time approval queue filtered for the active ward in view. |
| `guardian.warning` | `app/parent/index.tsx:56-62` | `guardian` | `v2` | `listGuardianPermissions` | Banner alert summarizing unapproved pending requests blocking campus exit. |
| `guardian.cross-ward-nudge` | `app/parent/index.tsx:66-72` | `guardian` | `v2` | `listSelfChildren` | Alert badge indicating pending requests waiting on siblings under the same guardian account. |
| `guardian.ward-switcher` | `components/WardContext.tsx` | `guardian` | `v2` | `listSelfChildren` | Multi-ward switcher for parents with multiple enrolled students. |
| `guardian.history` | `app/parent/history.tsx` | `guardian` | `v2` | `listGuardianPermissions` | Historical archive of past decisions (Approved, Rejected, Expired) for the active ward. |
| `guardian.ward-overview` | `app/parent/ward.tsx` | `guardian` | `v2` | `getSelfChild` | Ward live status: on-campus vs currently out, last gate scan, hostel room, room warden. |
| `guardian.call-warden` | `app/parent/ward.tsx:147` | `guardian` | `client-native` | `getSelfChild` | Dispatches native phone dialer intent (`tel:`) using warden contact from child record. |
| `guardian.message-student` | `app/parent/ward.tsx:149` | `guardian` | `client-native` | `getSelfChild` | Dispatches native SMS messenger intent (`sms:`) using student contact from child record. |
| `guardian.emergency` | `app/parent/ward.tsx:151` | `guardian` | `v2` | `createEmergency` | Triggers emergency alert broadcast to campus wardens and administration. |
| `guardian.late-entry-list` | `app/parent/late-entries.tsx` | `guardian` | `v2` | `listSelfChildLateEntries` | Detailed audit log of overdue curfew returns with expected vs actual gate scan timestamps. |
| `guardian.late-entry-acknowledge` | `app/parent/late-entries.tsx:86` | `guardian` | `v2` | `acknowledgeSelfChildLateEntry` | Clears unacknowledged late return badge for the guardian. |
| `profile.read-only` | `components/ProfileBody.tsx` | `common` | `v2` | `getSelf` | Locked personal profile view displaying official student/guardian/staff records. |
| `profile.last-request` | `components/ProfileBody.tsx:152-186` | `student-guardian` | `v2` | `listSelfProfileRequests` | Inline status banner of pending profile amendment request preventing duplicate submissions. |
| `profile.request-builder` | `app/profile-request.tsx` | `student-guardian` | `v2` | `createSelfProfileRequest` | Diff builder comparing current values with proposed changes, reason, and attachments. |
| `profile.field-whitelist` | `constants/sample.ts:451-466` | `student-guardian` | `v2` | `listProfileRequestFields` | Server-driven whitelist of editable fields per tenant and role. |
| `profile.proof` | `app/profile-request.tsx:150-170` | `student-guardian` | `v2` | `createUpload` | Upload supporting document/proof for proposed profile changes. |
| `profile.admin-queue` | `app/admin/profile-requests.tsx` | `admin-warden` | `v2` | `listProfileRequests` | Staff review queue with visual diff (strikethrough old value -> highlighted new value). |
| `profile.view-attachment` | `app/admin/profile-requests.tsx:150` | `admin-warden` | `v2` | `createUploadDownloadUrl` | Secure short-lived presigned URL generation to review submitted evidence. |
| `profile.approve` | `app/admin/profile-requests.tsx:157` | `admin-warden` | `v2` | `approveProfileRequest` | Applies approved changes directly to student/guardian record with audit trail. |
| `profile.reject` | `app/admin/profile-requests.tsx:156` | `admin-warden` | `v2` | `rejectProfileRequest` | Rejects proposed changes with feedback note sent to requester. |
| `profile.export` | `app/admin/profile-requests.tsx:39` | `admin` | `v2` | `createProfileRequestExportJob` | Initiates asynchronous CSV/PDF background export job for profile requests. |
| `admin.stats` | `constants/sample.ts:644-667` | `admin-warden` | `v2` | `getDashboard` | Server-aggregated metrics: Pending permissions, Approved today, Currently out, Overdue returns. |
| `admin.activity` | `app/admin/index.tsx:69-82` | `admin-warden-security` | `v2` | `listDashboardActivity` | Real-time audit log of campus gate crossings, emergency alerts, and approvals. |
| `admin.permissions` | `app/admin/requests.tsx` | `admin-warden` | `v2` | `listPermissions` | Campus-wide searchable and filterable permission register. |
| `admin.export` | `app/admin/requests.tsx:30` | `admin` | `v2` | `createReportJob` | Spawns asynchronous report generation job for campus movement logs. |
| `admin.scan-pass` | `app/admin/index.tsx:20` | `admin` | `obsolete` | *None* | Retired quick-tool; gate scanning is handled by edge biometric terminals, not admin app. |
| `admin.announce` | `app/admin/index.tsx:21` | `admin-warden` | `v2` | `createAnnouncement` | Broadcasts targeted notifications to hostel blocks or user cohorts. |
| `admin.reports` | `app/admin/index.tsx:22` | `admin` | `v2` | `createReportJob`, `getJob` | Report generation status dashboard and artifact retrieval. |
| `admin.roles` | `app/admin/profile.tsx:33` | `admin` | `v2` | `listTenantRoles`, `updateMembership`, `listMembershipCapabilities` | Tenant role inspection and user membership role assignment. |
| `groups.list` | `app/admin/groups.tsx` | `admin` | `v2` | `listGroups` | Lists hostel student groups with custom branding status and cohort counts. |
| `groups.create` | `app/admin/groups.tsx` | `admin` | `v2` | `createGroup` | Creates new student group/cohort. |
| `groups.editor` | `app/icon-editor.tsx` | `admin` | `v2` | `replaceGroupBranding` | Configures group branding palette, monogram, gradient presets, and title. |
| `groups.upload-icon` | `app/icon-editor.tsx` | `admin` | `v2` | `createUpload`, `replaceGroupBranding` | Uploads square 1024x1024 icon artwork and links to group branding configuration. |
| `groups.roster` | `app/icon-editor.tsx` | `admin` | `v2` | `getRoster`, `replaceGroupMembers` | Cohort member selector with search by roll number and branded tags. |
| `groups.apply` | `app/icon-editor.tsx` | `admin` | `v2` | `replaceGroupMembers`, `replaceGroupBranding` | Commits roster membership and branding styles in atomic update. |
| `groups.effective-branding` | `app/index.tsx` | `common` | `v2` | `getSelfBranding` | Retrieves assigned group branding, colors, monogram, and title on launch. |
| `groups.launcher-icon` | `app/index.tsx` | `common` | `client-native` | *None* | Triggers native alternate launcher icon switch via Expo / react-native-change-icon. |
| `notifications.badge` | `components/Screen.tsx` | `common` | `v2` | `getSelfNotificationUnreadCount` | Header badge indicator displaying unread notification counter. |
| `notifications.guardian-alert` | `app/student/request.tsx:90` | `guardian` | `v2` | `listSelfNotifications` | Push and in-app alert dispatched to guardian upon student submission. |
| `notifications.rejection-alert` | `app/outpass/[id].tsx:168` | `student` | `v2` | `listSelfNotifications` | Push and in-app alert dispatched to student with rejection rationale. |
| `notifications.preferences` | `components/ProfileBody.tsx:123` | `common` | `v2` | `getSelfNotificationPreferences`, `replaceSelfNotificationPreferences` | Controls push notification channel subscriptions. |
| `settings.language` | `components/ProfileBody.tsx` | `common` | `v2` | `getAppConfig` | Supported UI languages from tenant application configuration. |
| `settings.support` | `components/ProfileBody.tsx` | `common` | `v2` | `getAppConfig` | Campus warden and tech support help contacts from tenant application configuration. |
| `settings.legal` | `components/ProfileBody.tsx` | `common` | `v2` | `getAppConfig` | Terms of service and privacy policy URLs from tenant application configuration. |
| `obsolete.python-edge` | `legacy-hardware` | `none` | `obsolete` | *None* | Direct socket communication with legacy Python edge service replaced by v2 cloud APIs. |
| `obsolete.camera-webrtc` | `legacy-hardware` | `none` | `obsolete` | *None* | Direct camera WebRTC streaming to mobile app removed; edge handles computer vision locally. |
| `obsolete.custom-gallery-vector` | `legacy-hardware` | `none` | `obsolete` | *None* | Raw gallery vector calculation on mobile removed; biometric verification handled by edge. |
| `obsolete.edge-ota` | `legacy-hardware` | `none` | `obsolete` | *None* | Direct edge over-the-air firmware updates from mobile client retired. |
| `prohibited.m50-door` | `security-boundary` | `none` | `prohibited` | *None* | Direct door latch trigger from mobile is strictly forbidden; ingress requires verified edge scan. |
| `prohibited.m50-reboot` | `security-boundary` | `none` | `prohibited` | *None* | Direct physical terminal reboot from mobile client is prohibited. |
| `prohibited.m50-firmware` | `security-boundary` | `none` | `prohibited` | *None* | Direct physical terminal firmware manipulation from mobile client is prohibited. |
| `prohibited.m50-network` | `security-boundary` | `none` | `prohibited` | *None* | Direct physical terminal network configuration from mobile client is prohibited. |
| `prohibited.m50-wipe` | `security-boundary` | `none` | `prohibited` | *None* | Remote wipe of physical terminal hardware from mobile client is prohibited. |
| `prohibited.m50-log-delete` | `security-boundary` | `none` | `prohibited` | *None* | Terminal audit log deletion from mobile client is prohibited. |

---

## 4. Invariant Enforcement & Verification

1. **Strict Machine-Checkable Parity**: This document directly mirrors the authoritative YAML catalog in `contracts/matrices/mobile-screen-controls.yaml`.
2. **Automated CI Validation**: Verified by `packages/mobile-handoff/tests/matrices.test.ts` on every build.
3. **Rollback Safety**: Matrix rollback never re-activates obsolete or prohibited controls. Any newly added screen control must be classified and tested before deployment.
