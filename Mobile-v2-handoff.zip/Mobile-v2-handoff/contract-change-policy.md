# Mobile Contract Change Policy

This policy governs the evolution, validation, and versioning of the OpenAPI 3.1 specification for the Iverto Hostel V2 API. It establishes rules to protect mobile clients from breaking changes, enforces bundle hash pinning, defines change request procedures, and outlines the relationship between contract updates and minimum version enforcement.

---

## 1. Contract Hash Governance & Bundle Pinning

The canonical OpenAPI contract for Hostel V2 is maintained as a dereferenced bundle at `contracts/openapi/hostel-v2.bundle.yaml`. To ensure reproducibility and prevent unverified drifting:

1. **Deterministic Bundle Fingerprint**: Every change to contract components or paths must re-generate the bundle and compute its SHA-256 digest, saved directly to `contracts/openapi/hostel-v2.bundle.sha256`.
2. **Bundle Hash Format**: The contract hash adheres to the strict pattern `^sha256:[a-f0-9]{64}$`.
3. **Pinning in Mobile Releases**: The external mobile app must pin against this exact `contract hash`. When submitting builds for staging acceptance, the external app acceptance manifest must declare the contract hash against which it was compiled and verified.
4. **Automated Drift Detection**: CI pipelines verify that `contracts/openapi/hostel-v2.bundle.yaml` matches the dereferenced output of `contracts/openapi/openapi.yaml` and matches `contracts/openapi/hostel-v2.bundle.sha256`. If the computed hash diverges from the stored file, CI fails immediately.

---

## 2. Semantic Versioning & Change Classification

Hostel V2 follows Semantic Versioning (SemVer) with explicit classifications defined in `contracts/openapi/mobile-change-policy.yaml`:

### Non-Breaking Changes (Allowed after Automated Contract Tests)
These changes maintain backward compatibility with deployed mobile clients:
- **Additive optional request fields**: Adding a new property to a request body or query parameter where `required: false`.
- **Additive response fields**: Adding new fields to response schemas (mobile models use loose parsing to tolerate unknown additive fields).
- **Additive problem codes**: Introducing a new RFC 9457 `code` value under an existing HTTP error status, provided a generic fallback handler exists.
- **Additive operations**: Introducing entirely new endpoints or operations without mutating existing paths.

### Breaking Changes: Immediate Rejection
The following changes are strictly prohibited on active API versions:
- **Removed operations**: Deleting or retiring an endpoint.
- **Changed HTTP methods or paths**: Modifying URI paths, path parameters, or HTTP verbs.
- **Newly required request fields**: Making an existing optional parameter required, or introducing a new mandatory property in a request body.
- **Narrowed response enums**: Removing a value from an enum returned in response payloads.
- **Changed security schemes**: Altering authorization headers, token types, or authentication mechanisms.
- **Removed problem codes**: Deleting an established error code that clients rely on for conditional branching.

### Breaking Changes: Requiring External App Acceptance
Certain structural adjustments require explicit coordination and signed sign-off from the mobile team:
- **Changed authentication sequence**: Altering discovery, password/OTP login, or MFA challenge flows.
- **Changed refresh token rotation**: Modifying token lifetimes, family rotation rules, or replay detection semantics.
- **Changed deep link scheme or payloads**: Modifying URL structures or path parameters used in universal links or push payloads.
- **Changed permission lifecycle states**: Adding or altering terminal states in the hostel permission state machine.
- **Raised minimum app version**: Raising the `minimum app version` threshold in `/app-config`.

---

## 3. Contract Change Request Workflow

Any change to the contract must progress through the following sequential stages:

```
[ RFC / Issue ] ──> [ OpenAPI Spec Edit ] ──> [ Bundle Rebuild ] ──> [ Schema / Mock Tests ] ──> [ Staging Conformance ] ──> [ Signed External Acceptance ]
```

1. **Request for Change (RFC)**:
   - The proposer creates an engineering issue detailing the business justification, affected operations, and classification (non-breaking vs breaking).
   - If classified as breaking, the mobile team must be notified prior to code changes.

2. **Contract Modification**:
   - Update `contracts/openapi/openapi.yaml` and relevant path/component files.
   - All newly declared operations must include required OpenAPI extensions:
     - `x-actor-types`
     - `x-capability`
     - `x-mfa-level`
     - `x-idempotency`
     - `x-concurrency`
     - `x-rate-limit-class`
     - `x-audit-class`
     - `x-sensitive-fields`

3. **Bundle Generation and Hash Verification**:
   - Run the contract bundling command to regenerate `hostel-v2.bundle.yaml` and update `hostel-v2.bundle.sha256`.
   - Update TypeScript client models in `packages/mobile-handoff/src/client/models.ts`.

4. **Automated Verification**:
   - Execute the test suite: `npm --prefix packages/mobile-handoff test`.
   - Ensure all mock examples, MSW handlers, and Bruno tests validate against the updated bundle.

5. **Staging Verification & External Acceptance**:
   - Deploy changes to the staging environment.
   - If the change requires external acceptance, coordinate with the external mobile team. The external team verifies their updated build against staging and publishes a new `external app commit`.
   - An acceptance manifest linking the `external app commit`, build numbers, and new `contract hash` must be signed before production deployment.

---

## 4. Minimum Version and Legacy Server Code Retention

1. **Server V1 Code Retention**: Under no circumstances may legacy v1 backend endpoints or fallback compatibility shims be removed before signed external acceptance is finalized and verified across all production release channels.
2. **Minimum App Version Escalation**: The platform configuration for `minimum app version` must never be raised to exclude older builds until the external mobile team has verified that at least 98% of active daily users have updated to a compatible release, or an emergency security advisory mandates immediate cut-off.
