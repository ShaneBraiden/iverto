# Mocking and Contract Testing Guide

This guide details the local mock architecture, MSW integration, Bruno smoke tests, contract testing philosophy, and zero-secrets policy for the mobile handoff package.

---

## 1. Local Node Mock Server

The local mock server provides dynamic, contract-bound mock responses for all 201 OpenAPI operations in Hostel V2 without requiring backend infrastructure or live databases.

### Key Characteristics
- **Strict Loopback Binding**: Binds exclusively to `127.0.0.1:4010` (never `0.0.0.0`).
- **Base URL Prefix**: Routes are exposed under `http://127.0.0.1:4010/hostel/v2`.
- **Health Check**: `GET /health` responds with `200 OK` and `{"status":"ok"}` for liveness probes (used by `start-server-and-test`).
- **Dynamic OpenAPI Parsing**: Uses `@apidevtools/swagger-parser` to dereference `contracts/openapi/hostel-v2.bundle.yaml` at runtime, ensuring mock routes match exact contract paths and schemas.
- **Contract Example Serving**: Serves the first declared 2xx example for every operation, falling back to sanitized fixtures from `contracts/mocks/manifest.yaml` and cataloged examples in `contracts/generated/hostel-v2.examples.json`.
- **RFC 9457 Problem Details**: Unmatched routes return `404 Not Found` formatted as RFC 9457 Problem Details (`application/problem+json`).
- **Graceful Shutdown**: Intercepts `SIGINT` and `SIGTERM` to cleanly close HTTP listeners.

### Running the Server
```bash
# Start the mock server
npm --prefix packages/mobile-handoff run mock:start

# Validate that every JSON route has a conforming example (CI check)
npm --prefix packages/mobile-handoff run mock:start -- --check
```

---

## 2. MSW Integration

Mock Service Worker (MSW) handlers provide in-process network mocking for unit and component tests without spawning external processes.

### Export: `createMobileHandlers(baseUrl)`
Defined in `packages/mobile-handoff/src/mocks/handlers.ts`:
- `GET ${baseUrl}/tenants/:tenantId/me/permissions`: Serves paginated student permissions from `contracts/mocks/fixtures/cursor-permissions-page-1.json`.
- `GET ${baseUrl}/tenants/:tenantId/me/children`: Serves guardian-linked children from `contracts/mocks/fixtures/guardian-children.json`.
- `POST ${baseUrl}/tenants/:tenantId/me/guardian-permissions/:permissionId/decision`: Enforces optimistic concurrency via the `If-Match` header. If `If-Match !== "6"`, responds with `409 Conflict` (`PERMISSION_VERSION_CONFLICT`). If valid, returns the updated permission record.

### Usage in Vitest
```typescript
import { setupServer } from "msw/node";
import { createMobileHandlers } from "@iverto/mobile-handoff/mocks";

const server = setupServer(...createMobileHandlers("http://127.0.0.1:4010/hostel/v2"));
beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());
```

---

## 3. Bruno Smoke Test Collection

Executable API smoke tests are maintained in Bruno format under `contracts/mocks/bruno/`.

### Structure
- `contracts/mocks/bruno/bruno.json`: Collection configuration.
- `contracts/mocks/bruno/environments/local-mock.bru`: Environment definition setting `baseUrl: http://127.0.0.1:4010/hostel/v2`.
- `contracts/mocks/bruno/03-guardian/decision.bru`: Conflict-safe guardian decision request asserting `res.status === 200` when `If-Match: 6` and `Idempotency-Key` are provided.

### Running Smoke Tests
```bash
# Start server, wait for /health probe, run Bruno, and terminate server
npm --prefix packages/mobile-handoff run bruno:smoke
```

---

## 4. Contract Testing Philosophy

1. **Single Source of Truth**: All operations, status codes, schemas, and media types are defined in `contracts/openapi/hostel-v2.bundle.yaml` and validated by Ajv against JSON Schema Draft 2020-12.
2. **Contract-Driven Generation**: TypeScript models and operation catalogs are generated directly from the bundle (`npm run generate`).
3. **No Drift Between Mocks and Reality**: Mocks strictly reflect OpenAPI examples and declared schemas. Any change to API contracts must update OpenAPI definitions first, flowing down to mocks, generated types, and tests.
4. **Negative and Race Coverage**: Mocks explicitly represent concurrency race states (`409 Conflict`), auth revocations (`401 Unauthorized`), and version gates (`minimum-version-block`).

---

## 5. Zero-Secrets & Zero-PII Policy

Mocks, fixtures, and contract examples must **never** contain real credentials, live production keys, or personal identifiable information (PII).

### Rules
1. **Domains**: Use strictly `.test` or `.example` top-level domains (e.g. `tenant-a.test`, `example.com`). Never use `@gmail.com` or live tenant domains.
2. **Identifiers**: Use synthetic UUIDv7 or deterministic opaque IDs (e.g. `018f0000-0000-7000-8000-000000000001`).
3. **Tokens**: Use synthetic non-JWT or impossible token strings (e.g. `dummy-token-1`). Never commit `Bearer eyJ...` or live refresh tokens.
4. **Phone Numbers**: Synthetic non-routable numbers only (e.g. `15555550100`). No live Indian phone numbers (`+91\d{10}`).
5. **Names**: Synthetic names only (e.g. "Alice Smith", "Guardian Doe").
6. **Automated Verification**: Automated tests (`tests/mocks.test.ts`) scan manifests and serialized handler payloads against regex patterns:
   ```typescript
   expect(serialized).not.toMatch(/Bearer |refreshToken|signed.*token|@gmail\.com|\+91\d{10}/i);
   ```
