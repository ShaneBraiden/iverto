# Mobile Accessibility Checklist & WCAG Guidelines

This runbook establishes mandatory accessibility requirements for the Iverto Hostel V2 mobile application across iOS and Android. All screens and workflows must satisfy WCAG 2.1 Level AA criteria and mobile platform accessibility standards.

---

## 1. Executive Accessibility Checklist

| Requirement Area | Specification & Verification Criterion | iOS Minimum | Android Minimum | Status |
|---|---|---|---|---|
| **Touch Target Size** | Minimum interactive target area for all buttons, links, inputs, and toggles. | `44` pt x `44` pt | `48` dp x `48` dp | Required |
| **Screen Reader Semantics** | Every interactive element must provide an accessible name, role, hint, and logical traversal order. | VoiceOver | TalkBack | Required |
| **Dynamic Type & Scaling** | Layouts must scale up to 200% text enlargement without clipping, overlapping, or truncation. | Dynamic Type | Font Scaling (sp) | Required |
| **Color Contrast** | Minimum contrast ratio against adjacent backgrounds. | 4.5:1 text, 3:1 graphical UI | 4.5:1 text, 3:1 graphical UI | Required |
| **Non-Color Cues** | Status (Approved, Rejected, Pending, Expired) must never rely on color alone. | Text + Icon + Badge | Text + Icon + Badge | Required |
| **Keyboard & OTP Input** | Form semantics, auto-fill, focus navigation, and numeric pad for OTP. | `oneTimeCode`, Keypad | `smsOtp`, Number Keypad | Required |
| **Motion Sensitivity** | Disable or replace decorative and transitional animations when reduced motion is requested. | `reduced motion` API | Animator Duration Scale | Required |
| **Focus Restoration** | Returning from sheets, modals, alerts, and errors must restore focus to the triggering element. | `UIAccessibility.post` | `sendAccessibilityEvent` | Required |
| **RTL Layout Safety** | Bi-directional support for right-to-left scripts without broken flex ordering or clipped icons. | Native RTL mirrors | `android:supportsRtl` | Required |
| **Upload Progress** | Realtime percentage announcements and accessible status updates during file uploads. | `accessibilityValue` | Live Region (`polite`) | Required |
| **Connectivity & State** | Explicit announcements for offline, reconnecting, and 409 conflict states. | VoiceOver announce | Accessibility Live Region | Required |

---

## 2. Detailed Technical Requirements

### 2.1 Screen Reader Traversal and Labeling
- **Accessible Name & Value**: Every button, input, tab, and card must have a descriptive `accessibilityLabel` or `contentDescription` (e.g., "Approve Pass for John Doe, Roll number 102", not merely "Approve").
- **State Semantics**: Toggle switches, check boxes, and expand/collapse elements must announce their state (`accessibilityState={{ checked: true, expanded: false }}`).
- **Navigation Order**: Screen elements must follow a logical reading order (top-to-bottom, start-to-end). Modals, bottom sheets, and confirmation dialogs must trap accessibility focus until dismissed.
- **Auditing**: Verification requires manual testing with VoiceOver on iOS and TalkBack on Android, ensuring no silent un-focusable buttons exist.

### 2.2 Touch Target Sizing (44 pt / 48 dp)
- **Minimum Bounding Box**: All interactive controls must meet or exceed `44` pt on iOS and `48` dp on Android.
- **Small Visual Elements**: If an icon is visually smaller (e.g., a 20x20 close cross), its hit slop (`hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}`) must extend the touch area to satisfy the required boundary.
- **Spacing**: Maintain at least 8 pt/dp spacing between adjacent touch targets to prevent accidental triggers.

### 2.3 Text Scaling, Dynamic Type, and 200% Enlargement
- **Scalable Units**: All typography must use scalable units (points on iOS with Dynamic Type, scalable pixels `sp` on Android). Never hardcode pixel heights on text container wrappers.
- **200% Stress Test**: When system accessibility settings are configured to 200% font scale, all screens must wrap text properly without truncating critical information (such as approval dates, roll numbers, or emergency contacts) with ellipsis (`...`).

### 2.4 Color Contrast and Non-Color Status Cues
- **Contrast Standard**: All normal text must maintain at least 4.5:1 contrast against its background; large text (18 pt / 14 pt bold) and critical graphical controls must maintain at least 3:1.
- **Multi-Modal Status Indicators**: Status representations must never rely solely on color (e.g., green for approved, red for rejected). Every badge must pair the color with a distinct icon (checkmark, cross, clock) and unambiguous text labels.

### 2.5 Keyboard Semantics and OTP Keypads
- **OTP Fields**: Passcode/OTP fields must declare `keyboardType="number-pad"` (Android) or `keyboardType="numeric"` (iOS) and specify `textContentType="oneTimeCode"`.
- **Keyboard Dismissal**: Tapping outside an input or pressing the return key must cleanly dismiss virtual keyboards without obscuring submit buttons.

### 2.6 Reduced Motion Accommodations
- **Respect User Preference**: The application must monitor system motion settings via the platform `reduced motion` accessibility API.
- **Behavior**: When reduced motion is enabled, all non-essential spring animations, layout slides, and card flips must be converted to instantaneous state transitions or simple gentle fades.

### 2.7 Focus Management and Sheet Dismissal
- **Modal Opening**: When a bottom sheet or confirmation modal opens, focus must automatically move to the modal's primary heading or first interactive element.
- **Modal Dismissal**: When the sheet or alert closes, focus must be restored to the control that initially opened it.
- **Form Errors**: When a form validation error occurs upon submission, focus must shift to the first erroneous input and announce the error message via a live region.

### 2.8 Accessible Upload Progress & State Announcements
- **Upload Feedback**: File and document uploads must expose accessible progress bars with continuous percentage updates (`accessibilityValue={{ min: 0, max: 100, now: progress }}`) and announce upload completion.
- **Network State Changes**: Transitions into offline mode, reconnection to live networks, or optimistic concurrency version conflicts (`409 Conflict`) must trigger accessibility announcements so non-visual users are immediately aware of state changes.
