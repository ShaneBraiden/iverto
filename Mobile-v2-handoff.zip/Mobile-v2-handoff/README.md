# Mobile Handoff Package & Engineering Runbooks

Welcome to the **Iverto Hostel V2 Mobile Handoff Package**. This directory and the accompanying `@iverto/mobile-handoff` package provide everything required for external mobile developers, QA engineers, accessibility auditors, and release managers to build, verify, deploy, and operate the mobile application against Hostel V2 services.

---

## 1. Directory Structure & Quick Links

| Category | Document / Asset | Description |
|---|---|---|
| **Contract Specifications** | [OpenAPI 3.1 Bundle](../../contracts/openapi/hostel-v2.bundle.yaml) | Dereferenced 201-operation OpenAPI specification for Hostel V2. |
| | [Bundle Hash File](../../contracts/openapi/hostel-v2.bundle.sha256) | Canonical SHA-256 fingerprint (`contract hash`) securing contract integrity. |
| | [Contract Change Policy](contract-change-policy.md) | Semver governance, change request workflow, non-breaking vs breaking criteria. |
| **Client Models & Role APIs** | [Generated Client Models](../../packages/mobile-handoff/src/client/models.ts) | Strict TypeScript interfaces for all 201 operations and DTO schemas. |
| | [Role API Guide](role-api-guide.md) | Role-specific wrappers (`student`, `guardian`, `warden`, `admin`, `security`). |
| | [Query & Mutation Policies](../../packages/mobile-handoff/src/query/queries.ts) | TanStack Query definitions, stale times, garbage collection, and retry rules. |
| **Auth & Security** | [Auth & Session Guide](auth-session.md) | Tenant discovery, credentials, OTP, MFA, SecureStore token storage, session replay. |
| | [Security & Telemetry Redaction](security-redaction.md) | Strict telemetry allowlist and denylist preventing PII/credential leaks. |
| | [Environment & TLS Configuration](environment-and-tls.md) | Staging vs Production endpoints, TLS certificate validation, ATS and network configs. |
| **Domain Workflows** | [Permission Workflow](permission-workflow.md) | Optimistic concurrency (`If-Match`), versioning, race condition mitigations. |
| | [Notifications & Deep Links](notifications-realtime-deep-links.md) | Push token registration, Socket.IO realtime invalidation, URL routing map. |
| | [Dynamic Branding](branding.md) | Dual-accent palette, contrast fallbacks, logo caching, and splash configuration. |
| | [Document Uploads](uploads.md) | Presigned S3/MinIO upload flow, MIME validation, ClamAV antivirus quarantine. |
| **Matrices & Migration** | [Screen Control Matrix](screen-control-matrix.md) | Inventory of all 72 mobile controls classified across v2, obsolete, or prohibited. |
| | [V1 to V2 Migration Matrix](v1-v2-migration-matrix.md) | Screen-by-screen mapping from legacy Android/iOS endpoints to V2 contracts. |
| **Testing & Mocking** | [Mock & Contract Testing Guide](mock-and-contract-testing.md) | Loopback mock server (`http://127.0.0.1:4010`), MSW handlers, Bruno collections. |
| **Operational Runbooks** | [Offline Behavior Matrix](offline-behavior.md) | 5-state connectivity matrix, caching boundaries, mutation restrictions. |
| | [Accessibility Checklist](accessibility-checklist.md) | WCAG 2.1 AA checklist, touch targets (44 pt / 48 dp), screen readers, RTL. |
| | [Release & Rollback Runbook](release-and-rollback.md) | Release channels, crash triggers, minimum app version, external app commit tracking. |

---

## 2. Core Architectural Invariants

The mobile client architecture is governed by five non-negotiable invariants:

1. **Contract Hash Pinning**: All client models and test suites validate against the SHA-256 bundle hash recorded in `contracts/openapi/hostel-v2.bundle.sha256`. Client builds must record this contract hash in their acceptance manifests.
2. **Zero Plaintext Secrets / PII Leaks**: Access tokens exist strictly in memory. Refresh tokens are persisted only in platform-native secure hardware (`SecureStore` on Expo/React Native, Keychain on iOS, EncryptedSharedPreferences on Android). Telemetry and crash logs enforce a strict allowlist.
3. **Deterministic Offline Boundaries**: Offline access is permitted exclusively for non-sensitive cached projections until `offline expiry`. All mutating actions (approvals, passes, profile updates, payments) are strictly blocked when disconnected.
4. **Accessible by Design**: All user interactions satisfy WCAG 2.1 AA criteria, including 44 pt iOS / 48 dp Android touch targets, complete screen reader announcements, dynamic type up to 200%, and reduced motion accommodations.
5. **Controlled Release & Guaranteed Rollback**: Production rollout proceeds through gated channels. The server v1 API is retained without modification until signed external acceptance is submitted for an approved `external app commit`, and `minimum app version` enforcement is strictly coordinated.

---

## 3. Getting Started for Mobile Developers

### Step 1: Install Package Dependencies
From the repository root:
```bash
npm --prefix packages/mobile-handoff install
```

### Step 2: Start the Local Mock Server
Start the contract-bound loopback mock server serving mock fixtures at `http://127.0.0.1:4010/hostel/v2`:
```bash
npm --prefix packages/mobile-handoff run mock:start
```

### Step 3: Run Conformance Tests
Verify contract synchronization and migration matrices:
```bash
npm --prefix packages/mobile-handoff test
```
