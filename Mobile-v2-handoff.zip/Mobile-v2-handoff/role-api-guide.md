# Mobile Role-Specific API Guide & Coverage Manifest

## 1. Architectural Authority Invariant

> **AUTHORITATIVE SERVER AUTHORIZATION**:
> Client-side API wrappers, role interfaces, and typed facades exist solely to provide clean developer ergonomics, compile-time type safety, and automatic transmission of required transport headers (`Idempotency-Key`, `If-Match`).
>
> **Client wrappers do NOT grant authority, establish permissions, or replace server security evaluations.**
> Every backend endpoint strictly enforces actor types (`x-actor-types`), capabilities (`x-capability`), site scopes (`x-site-scope`), relationship rules (`x-relationship-rule`), and multi-factor authentication levels (`x-mfa-level`). Attempting to invoke unauthorized operations from a client wrapper will result in immediate server rejection (HTTP 401 Unauthorized or HTTP 403 Forbidden).

---

## 2. Role Coverage Matrix Overview

The system categorizes all endpoints across 12 families and 5 mobile roles (`student`, `guardian`, `warden`, `admin`, `security`), as defined in `contracts/matrices/mobile-role-coverage.yaml`:

| Endpoint Family | Student | Guardian | Warden | Admin | Security |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `public-auth` | `full` | `full` | `full` | `full` | `full` |
| `platform` | `none` | `none` | `none` | `none` | `none` |
| `tenant-site-membership` | `none` | `none` | `scoped` | `full` | `scoped` |
| `students-guardians-roster` | `none` | `none` | `scoped` | `full` | `minimal` |
| `self-children` | `self` | `linked` | `self` | `self` | `self` |
| `permissions` | `self` | `selected-approver` | `scoped` | `full` | `approved-read` |
| `presence-gate-curfew-dashboard-reports` | `self` | `linked` | `scoped` | `full` | `gate-scoped` |
| `visitors-visits` | `none` | `none` | `scoped` | `full` | `gate-actions` |
| `biometric-m50` | `consent-self` | `consent-linked` | `capability-scoped` | `capability-full` | `diagnostics` |
| `profile-emergency-announcement-group-branding` | `self-read` | `self-read` | `scoped` | `full` | `scoped-read` |
| `notifications-uploads-audit-jobs-config` | `self` | `self` | `scoped` | `full` | `scoped` |
| `provider-health-internal` | `none` | `none` | `none` | `none` | `none` |

---

## 3. Common API (`createCommonApi`)

Available to all authenticated principals across roles for personal profile, notification management, app config, session introspection, and file upload services.

| Wrapper Method | Operation ID | HTTP Method & Path | Idempotency | Version (If-Match) | MFA |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `getCurrentSession()` | `getCurrentSession` | `GET /auth/session` | Natural | None | 0 |
| `listCurrentPrincipalSessions()` | `listCurrentPrincipalSessions` | `GET /auth/sessions` | Natural | None | 0 |
| `revokeSession(sessionId)` | `revokeCurrentPrincipalSession` | `DELETE /auth/sessions/{sessionId}` | Natural | None | 0 |
| `getSelf()` | `getSelf` | `GET /tenants/{tenantId}/me` | Natural | None | 0 |
| `getAppConfig()` | `getAppConfig` | `GET /tenants/{tenantId}/app-config` | Natural | None | 0 |
| `listCategories()` | `listPermissionCategories` | `GET /tenants/{tenantId}/categories` | Natural | None | 0 |
| `listNotifications(query?)` | `listSelfNotifications` | `GET /tenants/{tenantId}/me/notifications` | Natural | None | 0 |
| `getSelfNotificationPreferences()` | `getSelfNotificationPreferences` | `GET /tenants/{tenantId}/me/notification-preferences` | Natural | None | 0 |
| `updateSelfNotificationPreferences(body, options?)` | `replaceSelfNotificationPreferences` | `PUT /tenants/{tenantId}/me/notification-preferences` | Optional | Optional | 0 |
| `getSelfNotificationUnreadCount()` | `getSelfNotificationUnreadCount` | `GET /tenants/{tenantId}/me/notifications/unread-count` | Natural | None | 0 |
| `markNotificationsRead(idempotencyKey?)` | `markAllSelfNotificationsRead` | `PATCH /tenants/{tenantId}/me/notifications/read-all` | Optional | None | 0 |
| `markNotificationRead(id, version?)` | `markSelfNotificationRead` | `PATCH /tenants/{tenantId}/me/notifications/{id}/read` | Natural | Optional | 0 |
| `registerPushDevice(body)` | `registerSelfPushDevice` | `POST /tenants/{tenantId}/me/push-devices` | Natural | None | 0 |
| `unregisterPushDevice(deviceId)` | `revokeSelfPushDevice` | `DELETE /tenants/{tenantId}/me/push-devices/{deviceId}` | Natural | None | 0 |
| `getTenantBranding()` | `getTenantBranding` | `GET /tenants/{tenantId}/branding` | Natural | None | 0 |
| `getSelfBranding()` | `getSelfBranding` | `GET /tenants/{tenantId}/me/branding` | Natural | None | 0 |
| `listProfileRequestFields()` | `listProfileRequestFields` | `GET /tenants/{tenantId}/profile-request-fields` | Natural | None | 0 |
| `listSelfProfileRequests(query?)` | `listSelfProfileRequests` | `GET /tenants/{tenantId}/me/profile-requests` | Natural | None | 0 |
| `getSelfProfileRequest(id)` | `getSelfProfileRequest` | `GET /tenants/{tenantId}/me/profile-requests/{id}` | Natural | None | 0 |
| `createSelfProfileRequest(body, idempotencyKey)` | `createSelfProfileRequest` | `POST /tenants/{tenantId}/me/profile-requests` | Required (`Idempotency-Key`) | None | 0 |
| `createUpload(body, idempotencyKey)` | `createUpload` | `POST /tenants/{tenantId}/uploads` | Required (`Idempotency-Key`) | None | 0 |
| `getUpload(fileId)` | `getUpload` | `GET /tenants/{tenantId}/uploads/{fileId}` | Natural | None | 0 |
| `createUploadDownloadUrl(fileId, idempotencyKey?)` | `createUploadDownloadUrl` | `POST /tenants/{tenantId}/uploads/{fileId}/download-url` | Optional (`Idempotency-Key`) | None | 0 |
| `deleteUpload(fileId)` | `deleteUpload` | `DELETE /tenants/{tenantId}/uploads/{fileId}` | Natural | None | 0 |

---

## 4. Student API (`createStudentApi`)

Scoped to the authenticated student's own projection (`self_only`), personal permissions, presence records, curfew schedule, and biometric consent responses.

| Wrapper Method | Operation ID | HTTP Method & Path | Idempotency | Version (If-Match) | MFA |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `getSelfStudent()` | `getSelfStudent` | `GET /tenants/{tenantId}/me/student` | Natural | None | 0 |
| `getStudentPresence(studentId)` | `getStudentPresence` | `GET /tenants/{tenantId}/presence/students/{studentId}` | Natural | None | 0 |
| `getSelfPermissionSummary()` | `getSelfPermissionSummary` | `GET /tenants/{tenantId}/me/permissions/summary` | Natural | None | 0 |
| `listSelfPermissions(query?)` | `listSelfPermissions` | `GET /tenants/{tenantId}/me/permissions` | Natural | None | 0 |
| `getSelfPermission(permissionId)` | `getSelfPermission` | `GET /tenants/{tenantId}/me/permissions/{permissionId}` | Natural | None | 0 |
| `createPermission(body, idempotencyKey)` / `submitSelfPermission(...)` | `submitSelfPermission` | `POST /tenants/{tenantId}/me/permissions` | Required (`Idempotency-Key`) | None | 0 |
| `cancelSelfPermission(permissionId, idempotencyKey?)` | `cancelSelfPermission` | `POST /tenants/{tenantId}/me/permissions/{permissionId}/cancel` | Optional (`Idempotency-Key`) | None | 0 |
| `getSelfCurfew()` | `getSelfCurfew` | `GET /tenants/{tenantId}/me/curfew` | Natural | None | 0 |
| `listBiometricConsents(query?)` | `listBiometricConsents` | `GET /tenants/{tenantId}/biometric-consents` | Natural | None | 0 |
| `recordBiometricConsent(id, body, options)` | `respondToBiometricConsent` | `POST /tenants/{tenantId}/biometric-consents/{id}/response` | Optional (`Idempotency-Key`) | Required (`If-Match`) | 0 |
| `withdrawBiometricConsent(id, options?)` | `withdrawBiometricConsent` | `POST /tenants/{tenantId}/biometric-consents/{id}/withdraw` | Optional (`Idempotency-Key`) | Optional (`If-Match`) | 0 |
| `createEmergency(body, idempotencyKey)` | `createEmergency` | `POST /tenants/{tenantId}/emergencies` | Required (`Idempotency-Key`) | None | 2 |

**Prohibited Methods on Student:**
`StudentApi` strictly omits `correctStudentPresence`, `overridePermission`, `rotateTerminalCredential`, `listStudents`, `approveProfileRequest`, and administrative endpoints.

---

## 5. Guardian API (`createGuardianApi`)

Scoped to verified linked wards (`self_or_ward`), late entry acknowledgments, biometric consents for wards, and guardian permission decision reviews.

| Wrapper Method | Operation ID | HTTP Method & Path | Idempotency | Version (If-Match) | MFA |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `listChildren()` | `listSelfChildren` | `GET /tenants/{tenantId}/me/children` | Natural | None | 0 |
| `getChild(studentId)` | `getSelfChild` | `GET /tenants/{tenantId}/me/children/{studentId}` | Natural | None | 0 |
| `listChildGuardians(studentId)` | `listSelfChildGuardians` | `GET /tenants/{tenantId}/me/children/{studentId}/guardians` | Natural | None | 0 |
| `listLateEntries(studentId, cursor?)` | `listSelfChildLateEntries` | `GET /tenants/{tenantId}/me/children/{studentId}/late-entries` | Natural | None | 0 |
| `acknowledgeLateEntry(id, idempotencyKey)` | `acknowledgeSelfChildLateEntry` | `POST /tenants/{tenantId}/me/late-entries/{id}/acknowledge` | Required (`Idempotency-Key`) | None | 0 |
| `listPermissions(query?)` | `listGuardianPermissions` | `GET /tenants/{tenantId}/me/guardian-permissions` | Natural | None | 0 |
| `getPermission(permissionId)` | `getGuardianPermission` | `GET /tenants/{tenantId}/me/guardian-permissions/{permissionId}` | Natural | None | 0 |
| `decidePermission(permissionId, input)` | `decidePermissionAsGuardian` | `POST /tenants/{tenantId}/me/guardian-permissions/{permissionId}/decision` | Required (`Idempotency-Key`) | Required (`If-Match`) | 0 |
| `listBiometricConsents(query?)` | `listBiometricConsents` | `GET /tenants/{tenantId}/biometric-consents` | Natural | None | 0 |
| `recordBiometricConsent(id, body, options)` | `respondToBiometricConsent` | `POST /tenants/{tenantId}/biometric-consents/{id}/response` | Optional (`Idempotency-Key`) | Required (`If-Match`) | 0 |
| `withdrawBiometricConsent(id, options?)` | `withdrawBiometricConsent` | `POST /tenants/{tenantId}/biometric-consents/{id}/withdraw` | Optional (`Idempotency-Key`) | Optional (`If-Match`) | 0 |
| `createEmergency(body, idempotencyKey)` | `createEmergency` | `POST /tenants/{tenantId}/emergencies` | Required (`Idempotency-Key`) | None | 2 |

**Prohibited Methods on Guardian:**
`GuardianApi` strictly omits `overridePermission`, `correctStudentPresence`, `rotateTerminalCredential`, `listStudents`, `createSite`, `decideVisit`, and administrative endpoints.

---

## 6. Warden API (`createWardenApi`)

Assigned-site operational duties including dashboard overview, student directory, staff permission decisions and escalation resolution, curfew violation resolution, visitor and visit handling, profile change approvals, and device diagnostics.

| Wrapper Method | Operation ID | HTTP Method & Path | Idempotency | Version (If-Match) | MFA |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `getDashboard(query?)` | `getDashboard` | `GET /tenants/{tenantId}/dashboard` | Natural | None | 1 |
| `getDashboardActivity(query?)` | `getDashboardActivity` | `GET /tenants/{tenantId}/dashboard/activity` | Natural | None | 1 |
| `listStudents(query?)` | `listStudents` | `GET /tenants/{tenantId}/students` | Natural | None | 1 |
| `getStudent(studentId)` | `getStudent` | `GET /tenants/{tenantId}/students/{studentId}` | Natural | None | 1 |
| `listStudentGuardians(studentId)` | `listStudentGuardians` | `GET /tenants/{tenantId}/students/{studentId}/guardians` | Natural | None | 1 |
| `getRoster(query?)` | `getRoster` | `GET /tenants/{tenantId}/roster` | Natural | None | 1 |
| `listPermissions(query?)` | `listPermissions` | `GET /tenants/{tenantId}/permissions` | Natural | None | 1 |
| `getPermission(permissionId)` | `getPermission` | `GET /tenants/{tenantId}/permissions/{permissionId}` | Natural | None | 1 |
| `decidePermission(permissionId, input)` | `decidePermissionAsWarden` | `POST /tenants/{tenantId}/permissions/{permissionId}/warden-decision` | Optional (`Idempotency-Key`) | Required (`If-Match`) | 1 |
| `activatePermission(permissionId, options)` | `activatePermission` | `POST /tenants/{tenantId}/permissions/{permissionId}/activate` | Optional (`Idempotency-Key`) | Required (`If-Match`) | 1 |
| `cancelPermission(permissionId, body?, options?)` | `cancelPermissionAsStaff` | `POST /tenants/{tenantId}/permissions/{permissionId}/cancel` | Optional (`Idempotency-Key`) | Optional (`If-Match`) | 1 |
| `escalatePermission(permissionId, body, options)` / `resolveEscalatedPermission(...)` | `resolveEscalatedPermission` | `POST /tenants/{tenantId}/permissions/{permissionId}/resolve-escalated` | Optional (`Idempotency-Key`) | Required (`If-Match`) | 2 |
| `correctStudentPresence(studentId, body, options)` | `correctStudentPresence` | `PUT /tenants/{tenantId}/presence/students/{studentId}` | Optional (`Idempotency-Key`) | Required (`If-Match`) | 1 |
| `listCurfewPolicies(siteId)` | `listCurfewPolicies` | `GET /tenants/{tenantId}/sites/{siteId}/curfew-policies` | Natural | None | 1 |
| `getCurfewPolicy(siteId, policyId)` | `getCurfewPolicy` | `GET /tenants/{tenantId}/sites/{siteId}/curfew-policies/{policyId}` | Natural | None | 1 |
| `listCurfewViolations(siteId, query?)` | `listCurfewViolations` | `GET /tenants/{tenantId}/sites/{siteId}/curfew-violations` | Natural | None | 1 |
| `resolveCurfewViolation(siteId, id, body, options)` | `resolveCurfewViolation` | `POST /tenants/{tenantId}/sites/{siteId}/curfew-violations/{id}/resolve` | Optional (`Idempotency-Key`) | Required (`If-Match`) | 1 |
| `listVisitors(query?)` | `listVisitors` | `GET /tenants/{tenantId}/visitors` | Natural | None | 1 |
| `getVisitor(visitorId)` | `getVisitor` | `GET /tenants/{tenantId}/visitors/{visitorId}` | Natural | None | 1 |
| `listVisits(query?)` | `listVisits` | `GET /tenants/{tenantId}/visits` | Natural | None | 1 |
| `getVisit(visitId)` | `getVisit` | `GET /tenants/{tenantId}/visits/{visitId}` | Natural | None | 1 |
| `createVisit(body, idempotencyKey)` | `createVisit` | `POST /tenants/{tenantId}/visits` | Required (`Idempotency-Key`) | None | 1 |
| `decideVisit(visitId, body, options)` | `decideVisit` | `POST /tenants/{tenantId}/visits/{visitId}/decision` | Optional (`Idempotency-Key`) | Required (`If-Match`) | 1 |
| `checkInVisit(visitId, options?)` | `checkInVisit` | `POST /tenants/{tenantId}/visits/{visitId}/check-in` | Optional (`Idempotency-Key`) | Optional (`If-Match`) | 1 |
| `checkOutVisit(visitId, options?)` | `checkOutVisit` | `POST /tenants/{tenantId}/visits/{visitId}/check-out` | Optional (`Idempotency-Key`) | Optional (`If-Match`) | 1 |
| `cancelVisit(visitId, options?)` | `cancelVisit` | `POST /tenants/{tenantId}/visits/{visitId}/cancel` | Optional (`Idempotency-Key`) | Optional (`If-Match`) | 1 |
| `listProfileRequests(query?)` | `listProfileRequests` | `GET /tenants/{tenantId}/profile-requests` | Natural | None | 1 |
| `getProfileRequest(id)` | `getSelfProfileRequest` | `GET /tenants/{tenantId}/me/profile-requests/{id}` | Natural | None | 0 |
| `approveProfileRequest(id, body, options)` | `approveProfileRequest` | `POST /tenants/{tenantId}/profile-requests/{id}/approve` | Required (`Idempotency-Key`) | Required (`If-Match`) | 2 |
| `rejectProfileRequest(id, body, options)` | `rejectProfileRequest` | `POST /tenants/{tenantId}/profile-requests/{id}/reject` | Required (`Idempotency-Key`) | Required (`If-Match`) | 1 |
| `listEmergencies(query?)` | `listEmergencies` | `GET /tenants/{tenantId}/emergencies` | Natural | None | 1 |
| `getEmergency(id)` | `listEmergencies` | `GET /tenants/{tenantId}/emergencies` (projection) | Natural | None | 1 |
| `acknowledgeEmergency(id, body, options)` | `acknowledgeEmergency` | `POST /tenants/{tenantId}/emergencies/{id}/acknowledge` | Required (`Idempotency-Key`) | Required (`If-Match`) | 1 |
| `resolveEmergency(id, body, options)` | `resolveEmergency` | `POST /tenants/{tenantId}/emergencies/{id}/resolve` | Required (`Idempotency-Key`) | Required (`If-Match`) | 2 |
| `createEmergency(body, idempotencyKey)` | `createEmergency` | `POST /tenants/{tenantId}/emergencies` | Required (`Idempotency-Key`) | None | 2 |
| `listAnnouncements(query?)` | `listAnnouncements` | `GET /tenants/{tenantId}/announcements` | Natural | None | 0 |
| `getAnnouncement(id)` | `listAnnouncements` | `GET /tenants/{tenantId}/announcements` (projection) | Natural | None | 0 |
| `createAnnouncement(body, idempotencyKey)` | `createAnnouncement` | `POST /tenants/{tenantId}/announcements` | Required (`Idempotency-Key`) | None | 2 |
| `createReportJob(body, idempotencyKey)` | `createReportJob` | `POST /tenants/{tenantId}/report-jobs` | Required (`Idempotency-Key`) | None | 2 |
| `getJob(jobId)` | `getJob` | `GET /tenants/{tenantId}/jobs/{jobId}` | Natural | None | 1 |
| `listJobs(query?)` | `listJobs` | `GET /tenants/{tenantId}/jobs` | Natural | None | 1 |
| `listTerminals(query?)` | `listTerminals` | `GET /tenants/{tenantId}/terminals` | Natural | None | 1 |
| `getTerminal(deviceId)` | `getTerminal` | `GET /tenants/{tenantId}/terminals/{deviceId}` | Natural | None | 1 |
| `getTerminalDiagnostics(deviceId)` | `getTerminalDiagnostics` | `GET /tenants/{tenantId}/terminals/{deviceId}/diagnostics` | Natural | None | 1 |

**Prohibited Methods on Warden:**
`WardenApi` strictly omits `rotateTerminalCredential`, `quarantineTerminal`, `overridePermission`, `createSite`, `retireSite`, and `createLegalHold`.

---

## 7. Security API (`createSecurityApi`)

Gate-scoped operational tasks: roster/presence verification, approved permission status checking, visit entry/exit, terminal health diagnostics, and emergency visibility.

| Wrapper Method | Operation ID | HTTP Method & Path | Idempotency | Version (If-Match) | MFA |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `getRoster(query?)` | `getRoster` | `GET /tenants/{tenantId}/roster` | Natural | None | 1 |
| `getStudentPresence(studentId)` | `getStudentPresence` | `GET /tenants/{tenantId}/presence/students/{studentId}` | Natural | None | 0 |
| `getPermission(permissionId)` | `getPermission` | `GET /tenants/{tenantId}/permissions/{permissionId}` | Natural | None | 1 |
| `checkInVisit(visitId, options?)` | `checkInVisit` | `POST /tenants/{tenantId}/visits/{visitId}/check-in` | Optional (`Idempotency-Key`) | Optional (`If-Match`) | 1 |
| `checkOutVisit(visitId, options?)` | `checkOutVisit` | `POST /tenants/{tenantId}/visits/{visitId}/check-out` | Optional (`Idempotency-Key`) | Optional (`If-Match`) | 1 |
| `getVisit(visitId)` | `getVisit` | `GET /tenants/{tenantId}/visits/{visitId}` | Natural | None | 1 |
| `listVisits(query?)` | `listVisits` | `GET /tenants/{tenantId}/visits` | Natural | None | 1 |
| `listAnnouncements(query?)` | `listAnnouncements` | `GET /tenants/{tenantId}/announcements` | Natural | None | 0 |
| `listEmergencies(query?)` | `listEmergencies` | `GET /tenants/{tenantId}/emergencies` | Natural | None | 1 |
| `getEmergency(id)` | `listEmergencies` | `GET /tenants/{tenantId}/emergencies` (projection) | Natural | None | 1 |
| `getTerminalDiagnostics(deviceId)` | `getTerminalDiagnostics` | `GET /tenants/{tenantId}/terminals/{deviceId}/diagnostics` | Natural | None | 1 |
| `listNotifications(query?)` | `listSelfNotifications` | `GET /tenants/{tenantId}/me/notifications` | Natural | None | 0 |
| `getAppConfig()` | `getAppConfig` | `GET /tenants/{tenantId}/app-config` | Natural | None | 0 |

**Prohibited Methods on Security:**
`SecurityApi` strictly omits `rotateTerminalCredential`, `overridePermission`, `decidePermission`, `correctStudentPresence`, `createCurfewPolicy`, `createStudent`, `quarantineTerminal`, and visitor creation/approval.

---

## 8. Admin API (`createAdminApi`)

Super-set wrapper incorporating all Warden capabilities plus tenant configuration, site lifecycles, membership management, capability grants, manual permission overrides, legal holds, audit integrity inspections, and capability/MFA-gated terminal hardware operations.

Key Admin-Specific Operations:
- **Tenant & Posture**: `getTenant`, `updateTenant`, `getTenantAuthorizationPosture`, `listTenantRoles`.
- **Sites**: `listSites`, `getSite`, `createSite`, `updateSite`, `retireSite`.
- **Memberships & Capabilities**: `listMemberships`, `getMembership`, `updateMembership`, `replaceMembershipSites`, `listMembershipCapabilities`, `createMembershipCapability`, `revokeMembershipCapability`, `inviteStaff`, `inviteStudent`, `inviteGuardian`.
- **Student/Guardian Management**: `createStudent`, `updateStudent`, `softDeleteStudent`, `createStudentGuardian`, `updateStudentGuardian`, `deleteStudentGuardian`, `listStudentSiblings`, `listPresence`, `listGateEvents`.
- **Permission Overrides**: `createPermission`, `overridePermission` (`POST /permissions/{id}/manual-override`, MFA Level 2).
- **Curfew & Visitors**: `createCurfewPolicy`, `updateCurfewPolicy`, `createVisitor`, `updateVisitor`, `softDeleteVisitor`.
- **Groups & Branding**: `listGroups`, `createGroup`, `updateGroup`, `deleteGroup`, `replaceGroupMembers`, `replaceGroupBranding`, `replaceTenantBranding`, `uploadTenantBrandingLogo`.
- **Audit & Legal Holds**: `createAuditExportJob`, `listAuditEvents`, `getAuditEvent`, `getAuditIntegrity`, `listLegalHolds`, `createLegalHold`, `releaseLegalHold`.
- **Biometric Policies**: `getBiometricPolicy`, `replaceBiometricPolicy`, `requestBiometricConsent`.
- **Terminal Hardware**: `provisionTerminal`, `updateTerminal`, `revokeTerminal`, `quarantineTerminal`, `rebindTerminal`, `rotateTerminalCredential` (MFA Level 2), `openTerminalRegistrationWindow`, `startTerminalPhotoEnrollment`, `cancelTerminalEnrollment`, `syncTerminalEnrollment`, `captureTerminalTemplate`, `replicateTerminalTemplate`, `createTerminalTemplateCaptureJob`, `createTerminalTemplateDistributionJob`, `getTerminalTemplateCoverage`, `listTerminalDeviceUsers`, `getTerminalDeviceUser`, `getTerminalDeviceUserPhoto`, `reserveTerminalUserSlot`, `claimTerminalUserSlot`, `releaseTerminalUserSlotClaim`, `removeTerminalSubject`, `listTerminalUnclaimedSlots`, `listTerminalDeviceLogs`, `listTerminalDeviceAdminLogs`.
