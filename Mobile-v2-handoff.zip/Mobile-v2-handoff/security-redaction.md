# Security and Telemetry Redaction Policy

This policy governs the handling of sensitive parameters, credentials, Personally Identifiable Information (PII), and diagnostic telemetry across the Iverto Hostel V2 mobile application. It defines strict allowlist and denylist boundaries to ensure that no secret or PII leaks into logs, crash reporting systems, or analytics pipelines.

---

## 1. Zero Secret and Zero PII Architecture

The mobile client interacts with student and guardian records, biometric authorization events, gate activity, and identity credentials. To maintain regulatory compliance and zero-trust security:
- Sensitive credentials must never be written to persistent plaintext storage or client loggers.
- Memory holding authentication tokens must be purged upon session termination or invalidation.
- Telemetry engines (Crashlytics, Sentry, Datadog, Mixpanel, etc.) must be gated by a cryptographic scrubbing filter.

---

## 2. Telemetry Allowlist and Denylist Contract

## Telemetry Allowlist

Allowed: app semantic version, build number, platform/OS major version, contract hash, route template, operation ID, HTTP status, stable problem code, retry count, duration bucket, request ID, connection state, and coarse feature state.

Denied: authorization/cookie headers, access or refresh tokens, OTPs, invitation/recovery/MFA assertions, tenant/user/student/guardian IDs, names, roll numbers, phone numbers, emails, addresses, reasons, destinations, notes, documents, photos, biometrics, raw request/response bodies, query values, Socket.IO auth, provider payloads, signed URL query strings, and SecureStore values.

Redaction tests inspect console, analytics, crash breadcrumbs, network diagnostics, and native logs after login, refresh, push, deep link, upload, and failure flows.

---

## 3. Detailed Data Classification & Redaction Rules

### 3.1 Authentication and Hardware Tokens
- **Access Tokens**: Ephemeral JWTs held exclusively in application memory (never serialized to disk or printed).
- **Refresh Tokens**: Stored exclusively via hardware-backed platform storage using `SecureStore` (iOS Keychain / Android EncryptedSharedPreferences). When logging token lifecycle events, only record boolean state changes (e.g. `hasRefreshToken: true`), never token strings or hashes.
- **OTPs & MFA Credentials**: Passwords, 6-digit TOTP/SMS codes, biometric assertions, and recovery phrases must be masked in UI input components and completely excluded from logging breadcrumbs.

### 3.2 User Identifiers & Personal Data
- **Entity Identifiers**: Tenant IDs, user IDs, student IDs, guardian IDs, and warden IDs are sensitive metadata. Log entries must refer to generic route templates (e.g., `/tenants/{tenantId}/me/permissions`) rather than resolved URLs containing UUIDs or slugs.
- **Profile & Activity Data**: Names, student roll numbers, room assignments, phone numbers, email addresses, emergency contacts, pass reasons, travel destinations, parent messages, and notes must never be attached as telemetry properties or event tags.
- **Biometric & Media Records**: Raw face templates, biometric feature vectors, camera frames, photos, scanned document attachments, and MinIO presigned URL signatures are strictly prohibited from analytics and crash reports.

### 3.3 Diagnostic Telemetry Allowlist Specifications
Diagnostic payloads sent to telemetry or crash aggregators may include only the following pre-approved parameters:
- `appVersion`: App semantic version (e.g. `2.1.0`)
- `buildNumber`: Monotonic build identifier (e.g. `412`)
- `platform`: OS name and major version (e.g. `iOS 17`, `Android 14`)
- `contractHash`: Canonical OpenAPI bundle fingerprint (`contract hash`)
- `routeTemplate`: Dereferenced endpoint pattern (e.g. `/tenants/{tenantId}/me/permissions/{id}`)
- `operationId`: OpenAPI operation ID (e.g. `getStudentPermissions`)
- `httpStatus`: HTTP response status code (e.g. `200`, `401`, `409`)
- `problemCode`: Stable RFC 9457 problem code (e.g. `PERMISSION_VERSION_CONFLICT`)
- `retryCount`: Integer retry count (e.g. `0`, `1`, `2`)
- `durationBucket`: Coarse latency category (e.g. `<100ms`, `100-500ms`, `500-2000ms`, `>2000ms`)
- `requestId`: Server-issued tracing identifier (UUID from `x-request-id` header)
- `connectionState`: Network reachability state (`wifi`, `cellular`, `offline`)
- `coarseFeatureState`: Active navigation tab or screen name (e.g. `StudentPassList`, `GuardianApprovalQueue`)

---

## 4. Verification and Redaction Audit Protocol

Before any external app release candidate is certified:
1. **Automated Log Inspection**:
   - The test harness runs automated end-to-end flows: login, OTP submission, token refresh, push receipt, deep link dispatch, file upload, and simulated 401/409/500 errors.
   - The harness captures all console outputs, HTTP request/response logs, and crash reporter breadcrumbs.
   - An automated scanner verifies that zero regex matches exist for tokens (Bearer, JWT patterns), UUIDs, phone numbers, email formats, or sensitive query strings.
2. **Native Layer Audit**:
   - iOS unified logging (`os_log`) and Android Logcat buffers are dumped and audited to ensure third-party SDKs do not bypass application-level redaction filters.
3. **SecureStore Verification**:
   - Physical device storage inspection confirms that the `refresh token` is stored only inside the platform `SecureStore` sandbox, and that unencrypted SQLite/AsyncStorage databases contain zero tokens or sensitive profile records.
