# Deterministic Offline Behavior Runbook

This runbook specifies the offline caching, state transitions, UI presentation, and mutation restrictions for the Iverto Hostel V2 mobile application. It ensures that data integrity and security boundaries are maintained when network connectivity is intermittent, degraded, or absent.

---

## 1. 5-State Connectivity and Session Matrix

The mobile client transitions deterministically across five operational states based on network reachability and authentication token status:

| State | Read behavior | Mutation behavior |
|---|---|---|
| Online and valid session | Fetch/revalidate normally | Send with version and idempotency policy |
| Offline before access expiry | Show clearly stale, non-sensitive cached projections | Disable; do not queue guardian, warden, admin, security, upload, MFA, or profile decisions |
| Offline after access expiry | Hide protected detail and route to reconnect | Disable all protected mutations |
| Refresh rejected/replayed/revoked | Clear memory, SecureStore refresh token, query cache, and realtime | Require tenant-code authentication |
| Partial provider outage | Inbox remains source of truth; explain push/WhatsApp delay | Server API behavior remains authoritative |

---

## 2. Caching Policies and Stale Projections

### 2.1 Cache Retention and Scoping
- **Non-Sensitive Projections**: Summary lists, past approved passes, hostel policies, and static branding may be cached locally in memory or encrypted cache storage for rapid rendering.
- **Sensitive Projections**: Live QR codes, gate entry passes, active OTP challenges, biometric templates, and pending approval rosters must NOT be stored in unencrypted persistent storage.
- **Cache Eviction on Expiry**: When the access token expires (`offline expiry`), all protected screens must hide entity details and render a secure reconnection lock screen. Cached entity projections must not remain visible when the identity session has expired.

### 2.2 Visual Offline Indicators
Whenever the device enters an offline state:
1. An un-dismissible, persistent offline banner appears at the top of the viewport indicating: *"Offline mode - Displaying cached data"*.
2. A timestamp indicating when the data was last synchronized must be shown adjacent to the cached list or record (e.g., *"Updated 12 minutes ago"*).
3. Pull-to-refresh interactions must be disabled or immediately display an explicit *"No network connection"* toast.

---

## 3. Mutation Queuing and Disabling Rules

A core safety invariant of Hostel V2 is that **privileged mutations must never be queued offline**:

1. **Strictly Disabled Mutations**:
   - Guardian pass approvals / rejections
   - Warden overrides and gate activations
   - Security gate scans and entry/exit logging
   - Student new permission requests
   - Document and photo attachments
   - Profile edits and MFA configuration changes
2. **Rationale**:
   - Queuing approvals or gate operations while offline introduces severe race conditions, stale version conflicts (`409 Conflict`), and safety hazards (e.g., an offline guardian approving an out-pass that was already cancelled by the student or rejected by another guardian).
3. **UI Behavior**:
   - All mutation buttons (e.g., "Approve", "Reject", "Submit Pass", "Upload Document") must be rendered in an inactive, disabled state with an accessibility hint explaining that network connectivity is required.
   - Touching a disabled action must trigger an informational modal rather than enqueuing a background task.

---

## 4. Session Revocation and Purge Protocol

If token refresh fails due to a rejected, replayed, expired, or revoked token:
1. **Immediate Invalidation**: The client halts all background polling and disconnects Socket.IO realtime listeners.
2. **Storage Purge**: The client purges the in-memory access token, removes the `refresh token` from `SecureStore`, flushes all TanStack Query caches, and clears temporary media directories.
3. **Navigation Reset**: The user is navigated immediately to the root tenant discovery screen (`GET /tenant-discovery/{code}`), requiring re-authentication. Stale views are replaced immediately without allowing back-navigation.

---

## 5. Partial Provider Outage Handling

During third-party upstream degradation (e.g., Apple APNs, Google FCM, or WhatsApp delivery outages):
1. **Server In-App Authority**: The in-app notifications inbox (`GET /tenants/{tenantId}/me/notifications`) remains the single source of truth.
2. **User Communication**: If push notifications fail or are delayed, the application displays a contextual alert informing the guardian or student that message delivery channels are experiencing latency, and prompts them to check the in-app inbox directly.
