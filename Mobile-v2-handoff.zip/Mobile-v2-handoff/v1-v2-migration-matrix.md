# Mobile V1-to-V2 Migration Matrix

## 1. Overview

This document specifies the authoritative migration path from legacy Mobile v1 endpoints (`/v1/mobile/*`) to Hostel v2 contracts (`/hostel/v2/*`). It defines global architectural changes, error model transformations, field mappings, status lifecycle stability, and exhaustive route-by-route dispositions.

This specification mirrors the machine-readable matrix defined in `contracts/matrices/mobile-v1-v2.yaml`.

---

## 2. Global Architectural Changes

| Dimension | Legacy V1 Model | Hostel V2 Standard |
| :--- | :--- | :--- |
| **API Base Path** | `/v1/mobile` | `/hostel/v2` (tenant scoped: `/hostel/v2/tenants/{tenantId}/*`) |
| **Actor Terminology** | `parent` | `guardian` |
| **Authority Evaluation** | Request query/body role hints, tenant headers | Authoritative server session (`GET /auth/session`), JWT claims, site scopes, capabilities, relationships, step-up MFA |
| **Error Handling** | Ad-hoc `{ statusCode, error, message, details }` envelope | RFC 7807 `ProblemDetails` (`type`, `title`, `status`, `code`, `detail`, `instance`, `requestId`, `retryable`, `fieldErrors`) |
| **Pagination** | Flat root keys (`nextCursor`, `hasMore`) | Structured `page` object (`page: { nextCursor, hasMore }`) |
| **Upload References** | Direct storage keys (`supportingDocKeys`, `attachmentKey`, `iconKey`) | Opaque UUID `fileId` registered via presigned upload workflows |
| **Onboarding** | Role-link endpoints (`/onboarding/parent-link`, `/student-link`) | Unified cryptographic invitation activation (`POST /auth/invitations/{token}/activate`) |

---

## 3. Data Contract & Error Field Mappings

### 3.1 Field Renames & Replacements

| Legacy V1 Field | Hostel V2 Equivalent | Description |
| :--- | :--- | :--- |
| `nextCursor` | `page.nextCursor` | Cursor token encapsulated within structured pagination object |
| `hasMore` | `page.hasMore` | Boolean flag encapsulated within structured pagination object |
| `supportingDocKeys` | `fileId` (or array of `fileId`) | Replaced raw object storage keys with opaque server-managed file identifiers |
| `attachmentKey` | `fileId` | Single file reference replaced by opaque file ID |
| `iconKey` | `fileId` | Group branding icon reference replaced by opaque file ID |
| `signed-url key` | `downloadUrl` | Download URL generated on-demand via `POST /uploads/{fileId}/download-url` |
| `user.role: "parent"` | `session.role: "guardian"` | Session role normalized to `guardian` across all APIs |
| `tokenType`, `expiresIn` | `expiresAt` | Exact ISO 8601 UTC timestamp replaces relative integer seconds |

### 3.2 Error Envelope Transformation

| Legacy V1 Error Field | V2 ProblemDetails Field | Purpose |
| :--- | :--- | :--- |
| `statusCode` | `status` | HTTP status code (integer, e.g., 400, 403, 404, 409, 429) |
| `error` | `code` | Machine-readable error code string (e.g., `VALIDATION_FAILED`, `RESOURCE_CONFLICT`) |
| `message` | `detail` | Human-readable diagnostic description of the failure |
| `details` | `fieldErrors` | Array of per-field validation failures (`{ field, message, code }`) |
| *(None)* | `type` | URI reference identifying problem type documentation |
| *(None)* | `title` | Short, human-readable summary of the problem type |
| *(None)* | `instance` | URI reference identifying the specific occurrence of the problem |
| *(None)* | `requestId` | Server request correlation ID for debugging and tracing |
| *(None)* | `retryable` | Boolean indicating whether client may safely retry request |

### 3.3 Lifecycle Status Preservation

Status strings remain **byte-for-byte stable** between v1 and v2 to guarantee backward compatibility with existing reporting and database records, while UI and actor representations update to `guardian`:

- `draft`
- `pending_warden`
- `warden_approved`
- `waiting_parent` *(actor display label: Waiting Guardian)*
- `parent_approved` *(actor display label: Guardian Approved)*
- `active`
- `student_exited`
- `completed`
- `rejected_warden`
- `rejected_parent` *(actor display label: Guardian Rejected)*
- `expired`
- `cancelled`
- `escalated`
- `parent_unreachable` *(actor display label: Guardian Unreachable)*
- `contact_parent` *(actor display label: Contact Guardian)*

---

## 4. Route-by-Route Migration Table

| Legacy V1 Endpoint | Hostel V2 Endpoint(s) | Disposition | Migration Notes |
| :--- | :--- | :--- | :--- |
| `POST /v1/mobile/auth/login` | `GET /tenant-discovery/{code}`<br>`POST /auth/password/login`<br>`GET /auth/session` | `v2` | Discovery resolves tenant; password login issues session; session introspection yields authority. |
| `POST /v1/mobile/auth/forgot-password` | `POST /auth/password/recovery/request`<br>`POST /auth/password/recovery/complete` | `v2` | Two-phase password recovery replacing monolithic endpoint. |
| `POST /v1/mobile/auth/password` | `POST /auth/password/change` | `v2` | Password rotation requires active session and current password. |
| `POST /v1/mobile/auth/logout` | `POST /auth/logout` | `v2` | Revokes server session and invalidates active JWT. |
| `POST /v1/mobile/onboarding/parent-link` | `POST /auth/invitations/{token}/activate` | `invitation-replaced` | Unified cryptographic activation replaces ad-hoc role-link. |
| `POST /v1/mobile/onboarding/student-link` | `POST /auth/invitations/{token}/activate` | `invitation-replaced` | Unified cryptographic activation replaces ad-hoc role-link. |
| `GET /v1/mobile/me` | `GET /tenants/{tenantId}/me` | `v2` | Personal profile and contact information for authenticated user. |
| `GET /v1/mobile/app-config` | `GET /tenants/{tenantId}/app-config` | `v2` | Client configuration, language, legal URLs, and feature flags. |
| `GET /v1/mobile/categories` | `GET /tenants/{tenantId}/categories` | `v2` | Outpass leave categories. |
| `POST /v1/mobile/uploads` | `POST /tenants/{tenantId}/uploads` | `v2` | Initiates upload workflow returning signed storage URL and opaque `fileId`. |
| `GET /v1/mobile/uploads/signed-url` | `POST /tenants/{tenantId}/uploads/{fileId}/download-url` | `v2` | Generates short-lived download URL for uploaded asset by `fileId`. |
| `GET /v1/mobile/me/branding` | `GET /tenants/{tenantId}/me/branding` | `v2` | Effective branding assigned to user based on group membership. |
| `POST /v1/mobile/push/token` | `POST /tenants/{tenantId}/me/push-devices` | `v2` | Registers mobile device token for push notifications. |
| `DELETE /v1/mobile/push/token` | `DELETE /tenants/{tenantId}/me/push-devices/{deviceId}` | `v2` | Unregisters push notification device token. |
| `GET /v1/mobile/notifications` | `GET /tenants/{tenantId}/me/notifications` | `v2` | User notification feed with structured pagination. |
| `GET /v1/mobile/notifications/unread-count` | `GET /tenants/{tenantId}/me/notifications/unread-count` | `v2` | Badge counter endpoint for unread notifications. |
| `PATCH /v1/mobile/notifications/read-all` | `PATCH /tenants/{tenantId}/me/notifications/read-all` | `v2` | Marks all notifications as read for current user. |
| `PATCH /v1/mobile/notifications/:id/read` | `PATCH /tenants/{tenantId}/me/notifications/{id}/read` | `v2` | Marks single notification as read. |
| `GET /v1/mobile/notification-preferences` | `GET /tenants/{tenantId}/me/notification-preferences` | `v2` | Retrieves user notification channel settings. |
| `PUT /v1/mobile/notification-preferences` | `PUT /tenants/{tenantId}/me/notification-preferences` | `v2` | Replaces user notification channel preferences. |
| `GET /v1/mobile/permissions` | `GET /tenants/{tenantId}/me/permissions` | `v2` | Student outpass permission history. |
| `GET /v1/mobile/permissions/summary` | `GET /tenants/{tenantId}/me/permissions/summary` | `v2` | Student summary counters (pending, approved, active, rejected). |
| `GET /v1/mobile/permissions/:id` | `GET /tenants/{tenantId}/me/permissions/{permissionId}` | `v2` | Detailed student permission record with timeline events. |
| `POST /v1/mobile/permissions/submit` | `POST /tenants/{tenantId}/me/permissions` | `v2` | Idempotent student outpass submission requiring `Idempotency-Key`. |
| `POST /v1/mobile/permissions/:id/cancel` | `POST /tenants/{tenantId}/me/permissions/{permissionId}/cancel` | `v2` | Student cancellation of pending outpass request. |
| `GET /v1/mobile/curfew` | `GET /tenants/{tenantId}/me/curfew` | `v2` | Curfew schedule and late thresholds for student. |
| `GET /v1/mobile/parent/children` | `GET /tenants/{tenantId}/me/children` | `v2` | List of wards linked to authenticated guardian. |
| `GET /v1/mobile/parent/children/:studentId` | `GET /tenants/{tenantId}/me/children/{studentId}` | `v2` | Ward overview, room, hostel block, and status. |
| `GET /v1/mobile/parent/children/:studentId/guardians` | `GET /tenants/{tenantId}/me/children/{studentId}/guardians` | `v2` | Registered guardians and authorized approver for student. |
| `GET /v1/mobile/parent/children/:studentId/late-entries` | `GET /tenants/{tenantId}/me/children/{studentId}/late-entries` | `v2` | Overdue returns log for specific ward. |
| `POST /v1/mobile/parent/late-entries/:id/acknowledge` | `POST /tenants/{tenantId}/me/late-entries/{id}/acknowledge` | `v2` | Acknowledges overdue entry and clears guardian alert badge. |
| `POST /v1/mobile/parent/emergencies` | `POST /tenants/{tenantId}/emergencies` | `v2` | Guardian emergency alert dispatch. |
| `GET /v1/mobile/parent/permissions` | `GET /tenants/{tenantId}/me/guardian-permissions` | `v2` | Guardian approval queue and decision history across wards. |
| `GET /v1/mobile/parent/permissions/:id` | `GET /tenants/{tenantId}/me/guardian-permissions/{permissionId}` | `v2` | Guardian outpass view with student details and timeline. |
| `POST /v1/mobile/parent/permissions/:id/decision` | `POST /tenants/{tenantId}/me/guardian-permissions/{permissionId}/decision` | `v2` | Guardian decision requiring `Idempotency-Key` and `If-Match`. |
| `GET /v1/mobile/warden/permissions` | `GET /tenants/{tenantId}/permissions` | `v2` | Scoped outpass review queue for hostel wardens. |
| `POST /v1/mobile/warden/permissions/:id/decision` | `POST /tenants/{tenantId}/permissions/{permissionId}/warden-decision` | `v2` | Warden clearance decision with concurrency control. |
| `POST /v1/mobile/warden/permissions/:id/activate` | `POST /tenants/{tenantId}/permissions/{permissionId}/activate` | `v2` | Warden manual activation of cleared pass. |
| `POST /v1/mobile/warden/permissions/:id/resolve-escalated` | `POST /tenants/{tenantId}/permissions/{permissionId}/resolve-escalated` | `v2` | Resolves escalated permission request. |
| `GET /v1/mobile/warden/dashboard` | `GET /tenants/{tenantId}/dashboard` | `v2` | Warden dashboard overview and metrics. |
| `GET /v1/mobile/profile-requests/fields` | `GET /tenants/{tenantId}/profile-request-fields` | `v2` | Whitelist of profile fields eligible for edit requests. |
| `GET /v1/mobile/profile-requests` | `GET /tenants/{tenantId}/me/profile-requests` | `v2` | Self-submitted profile amendment requests. |
| `POST /v1/mobile/profile-requests` | `POST /tenants/{tenantId}/me/profile-requests` | `v2` | Submits profile amendment request with evidence attachment. |
| `GET /v1/mobile/profile-requests/:id` | `GET /tenants/{tenantId}/me/profile-requests/{id}` | `v2` | Detail of self-submitted profile request. |
| `GET /v1/mobile/admin/stats` | `GET /tenants/{tenantId}/dashboard` | `v2` | Campus-wide operations dashboard metrics. |
| `GET /v1/mobile/admin/activity` | `GET /tenants/{tenantId}/dashboard/activity` | `v2` | Campus activity audit stream. |
| `GET /v1/mobile/admin/permissions` | `GET /tenants/{tenantId}/permissions` | `v2` | Administrative campus-wide permission list. |
| `GET /v1/mobile/admin/permissions/export` | `POST /tenants/{tenantId}/report-jobs` | `v2` | Initiates asynchronous report export job for permissions. |
| `GET /v1/mobile/admin/permissions/:id` | `GET /tenants/{tenantId}/permissions/{permissionId}` | `v2` | Full permission record detail for administrators. |
| `POST /v1/mobile/admin/permissions/:id/override` | `POST /tenants/{tenantId}/permissions/{permissionId}/manual-override` | `v2` | Admin manual override requiring step-up MFA and reason. |
| `GET /v1/mobile/admin/profile-requests` | `GET /tenants/{tenantId}/profile-requests` | `v2` | Staff profile request review queue. |
| `GET /v1/mobile/admin/profile-requests/export` | `POST /tenants/{tenantId}/profile-request-export-jobs` | `v2` | Asynchronous export job for profile amendment requests. |
| `POST /v1/mobile/admin/profile-requests/:id/approve` | `POST /tenants/{tenantId}/profile-requests/{id}/approve` | `v2` | Staff approval applying profile changes to user record. |
| `POST /v1/mobile/admin/profile-requests/:id/reject` | `POST /tenants/{tenantId}/profile-requests/{id}/reject` | `v2` | Staff rejection of profile amendment request. |
| `GET /v1/mobile/admin/announcements` | `GET /tenants/{tenantId}/announcements` | `v2` | List of campus announcements. |
| `POST /v1/mobile/admin/announcements` | `POST /tenants/{tenantId}/announcements` | `v2` | Broadcasts new announcement to hostel blocks. |
| `GET /v1/mobile/admin/reports` | `POST /tenants/{tenantId}/report-jobs`<br>`GET /tenants/{tenantId}/jobs/{jobId}` | `v2` | Asynchronous report dispatch and status polling. |
| `GET /v1/mobile/admin/roles` | `GET /tenants/{tenantId}/roles`<br>`GET /tenants/{tenantId}/memberships` | `v2` | Tenant roles inspection and membership assignments. |
| `PUT /v1/mobile/admin/users/:userId/role` | `PATCH /tenants/{tenantId}/memberships/{membershipId}` | `v2` | Membership role assignment using membership ID. |
| `GET /v1/mobile/admin/emergencies` | `GET /tenants/{tenantId}/emergencies` | `v2` | Campus emergency alerts register. |
| `POST /v1/mobile/admin/emergencies/:id/resolve` | `POST /tenants/{tenantId}/emergencies/{id}/resolve` | `v2` | Resolves active emergency alert. |
| `GET /v1/mobile/admin/groups` | `GET /tenants/{tenantId}/groups` | `v2` | Lists student cohorts/groups. |
| `POST /v1/mobile/admin/groups` | `POST /tenants/{tenantId}/groups` | `v2` | Creates student cohort/group. |
| `GET /v1/mobile/admin/groups/:id` | `GET /tenants/{tenantId}/groups/{groupId}` | `v2` | Group configuration and metadata. |
| `POST /v1/mobile/admin/groups/:id/branding` | `PUT /tenants/{tenantId}/groups/{groupId}/branding`<br>`PUT /tenants/{tenantId}/groups/{groupId}/members` | `v2` | Atomic update of group branding and roster membership. |
| `GET /v1/mobile/admin/roster` | `GET /tenants/{tenantId}/roster` | `v2` | Student roster lookup for group assignment. |
| `GET /v1/mobile/outpasses/:id/pass` | *None* | `decorative` | Non-authoritative QR render; physical gate verification uses edge sensors. |
| `POST /v1/mobile/outpasses/:id/issue-pass` | *None* | `obsolete` | Retired legacy pass issuance flow replaced by server lifecycle transitions. |
| `POST /v1/mobile/gate/scan` | *None* | `prohibited` | Gate scanning is prohibited on mobile client; physical ingress is handled by edge terminals. |

---

## 5. Migration Compliance Verification

All mappings are validated using automated test and lint checks:
```bash
# Verify matrix completeness and schema invariants
npm --prefix packages/mobile-handoff exec vitest run tests/matrices.test.ts

# Ensure zero unclassified or unmapped rows
node -e "const fs=require('fs');for(const f of ['contracts/matrices/mobile-screen-controls.yaml','contracts/matrices/mobile-v1-v2.yaml']){const s=fs.readFileSync(f,'utf8');if(/unclassified|unknown-disposition|pending-mapping/i.test(s))process.exit(1)}"
```
