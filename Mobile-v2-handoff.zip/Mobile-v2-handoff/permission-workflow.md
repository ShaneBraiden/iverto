# Permission Workflow

- The server owns every transition. The app renders the returned status, timeline, selected guardian, and resource version.
- Student submission uses one idempotency key and creates the server-declared initial submitted state.
- Exactly one active guardian link is selected for a permission. Other linked guardians may receive the allowed read projection but never see enabled decision controls.
- A guardian decision sends `Idempotency-Key`, `If-Match`, and one of `approve`, `reject`, or `contact_warden`; version is a precondition header and is not a mass-assignable request field.
- App and WhatsApp use the same server transition. Replaying the same decision returns the current success. A different later decision returns a version/conflict problem.
- On conflict or a newer realtime resource version, disable actions, discard optimistic state, refetch detail and queues, and explain the returned final decision.
- Warden decision, guardian decision, activation, cancellation, escalation, expiry, exit, return, and manual override remain distinct timeline events.
- Manual override is admin-only, requires capability, reason, current version, and MFA; student, guardian, warden, and security wrappers do not expose it.
