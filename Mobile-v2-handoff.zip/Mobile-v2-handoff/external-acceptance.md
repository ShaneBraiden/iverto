# External Mobile Acceptance Gate

This document defines the strict gate protocol and verification sequence required before external mobile application builds are accepted for staging and production rollout.

## Acceptance Gate Sequence

1. Record the exact 40-character external app commit, semantic version, signed iOS build ID, and signed Android build ID.
2. Verify the checked-in OpenAPI SHA-256 equals the hash embedded in the external build's About/diagnostics screen.
3. Run schema/example/generated-client tests and managed staging contract tests for student, guardian, warden, admin, and security.
4. Execute every `v2` and `client-native` screen-control row and every v1-to-v2 mapping; record pass/fail and request IDs without user data.
5. Verify tenant discovery, invitation, password, OTP, MFA, refresh rotation/replay, recovery, tenant switch, revocation, logout, offline expiry, and SecureStore behavior on physical iOS and Android builds.
6. Verify selected-guardian app/WhatsApp races, cursor end/filter reset, idempotency/version conflicts, push foreground/background/killed behavior, inbox, realtime reconnect, allowlisted deep links, all three branding states, uploads/quarantine/signed URL expiry, and minimum-version soft/mandatory states.
7. Inspect console, native device logs, analytics, crash reports, proxy capture, and evidence output for denied data from the redaction policy.
8. Run screen-reader, dynamic-type, contrast, target-size, reduced-motion, keyboard, offline, stale, revoked, partial-outage, and rollback checks.
9. Generate sanitized evidence files, validate `acceptance-manifest.json`, and obtain signatures from the external mobile owner, Iverto security, and Iverto release authority.
10. Keep the release gate closed if the external commit/build is absent, a required row fails, evidence is unsigned, minimum-version behavior is unproven, or the contract hash differs.

## Execution and Evidence Policy

The automated staging suite validates discovery, one authorized read for every mobile role, and explicit student/guardian/warden/security overreach denials, then validates each response/problem against its OpenAPI operation/status. Seeded idempotency/version/race cases are added only when the staging reset contract can restore them safely; a contract test must never mutate production or claim external UI acceptance.

Complete wrapper, endpoint, and screen-control coverage is executed by the real external iOS and Android builds and recorded in `security/evidence/mobile-acceptance/endpoint-coverage.json`. Repository automation validates evidence integrity and schema conformance but cannot manufacture or waive external acceptance.

The runner connects exclusively to the staging base URL, redacts all request headers and bodies, and writes only operation ID, role, expected and actual HTTP status, duration, problem code, request ID, and pass/fail indicators.

Minimum version evaluation produces `supported`, `update_available`, or `update_required`. When `update_required` is triggered, protected navigation is blocked while preserving tenant discovery, update guidance, legal/support links, logout, and accessibility.
